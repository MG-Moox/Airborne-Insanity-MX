# Dirt Rush MX

A 3D motocross racing game with 50 tracks: 15 supercross, 15 motocross, 10 pit bike and 10 compound tracks.
Original name, bikes, tracks and artwork. Custom WebGL engine (shadows, bloom, FXAA, speed blur, tyre tracks), no build step, no dependencies.

## Run locally
```
npm start
```
Then open http://localhost:3000

## Deploy on Render
1. Put this folder in a GitHub repo (the `render.yaml` must be in the repo root).
2. On https://render.com choose **New + > Blueprint**, pick the repo and click **Apply**. (Or **New + > Web Service**, build command `echo ok`, start command `node server.js`.)
3. Render gives you a public `https://dirt-rush-mx.onrender.com`-style URL.

Static-site alternative: **New + > Static Site**, publish directory `public`, no build command.

## Controls
| Key | Action |
| --- | --- |
| Up / W | Throttle |
| Down / S | Brake |
| Left / Right, A / D | Steer |
| E / Space | Lean back (front wheel up) |
| Q / Shift | Lean forward |
| C | Camera: chase, far, helmet |
| R | Reset to last checkpoint |
| Esc / P | Pause |
| M | Mute |

Touch devices get on-screen buttons.

## Files
- `public/tracks.js` - procedural track builder (seeded, so tracks are the same every time)
- `public/gfx.js` - small dependency-free WebGL engine
- `public/render3d.js` - 3D terrain, scenery, bikes, riders, camera
- `public/game.js` - physics, steering, AI rivals, HUD, menu
- `public/index.html`, `public/style.css` - page and styling
