/* Dirt Rush MX - procedural track generator: 50 tracks */
(function () {
  'use strict';
  const DX = 0.25;

  function mulberry(a) {
    return function () {
      a |= 0; a = a + 0x6D2B79F5 | 0;
      let t = Math.imul(a ^ a >>> 15, 1 | a);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }
  const E = {
    lin: t => t,
    smooth: t => t * t * (3 - 2 * t),
    lip: t => Math.pow(t, 1.8),
    land: t => 1 - Math.pow(1 - t, 1.8)
  };

  class Builder {
    constructor(rnd) { this.h = [0]; this.rnd = rnd; this.cps = []; this.last = 0; }
    get y() { return this.h[this.h.length - 1]; }
    get x() { return (this.h.length - 1) * DX; }
    r(a, b) { return a + (b - a) * this.rnd(); }
    seg(len, dy, e) {
      const n = Math.max(1, Math.round(len / DX)), y0 = this.y, f = e || E.smooth;
      for (let i = 1; i <= n; i++) this.h.push(y0 + dy * f(i / n));
      return this;
    }
    flat(len) { return this.seg(len, 0, E.lin); }
    mark() { if (this.x - this.last >= 90) { this.cps.push(this.x); this.last = this.x; } return this; }
    wave(len, amp, fn) {
      const n = Math.max(1, Math.round(len / DX)), y0 = this.y;
      for (let i = 1; i <= n; i++) this.h.push(y0 + amp * fn(i / n));
    }
    whoops(n, sp, amp) {
      for (let i = 0; i < n; i++) this.wave(sp, amp, t => 1 - Math.pow(Math.abs(Math.cos(Math.PI * t)), 0.8));
    }
    rollers(n, wl, amp) {
      for (let i = 0; i < n; i++) this.wave(wl, amp, t => (1 - Math.cos(2 * Math.PI * t)) / 2);
    }
    jump(h, gap) {
      const lip = h * 3 + 0.6, lh = h * 0.7;
      this.seg(lip, h, E.lip);
      this.seg(1.8, -h, E.smooth);
      this.flat(Math.max(0, gap - 1.8));
      this.seg(lh * 4.2, lh, E.smooth); this.flat(0.5); this.seg(lh * 4.4, -lh, E.smooth);
    }
    table(h, top) { this.seg(h * 3 + 0.6, h, E.lip); this.flat(top); this.seg(h * 3.6, -h, E.smooth); }
    step(h) { this.seg(h * 2.2 + 0.5, h, E.smooth); }
    drop(h) { this.seg(h * 3, -h, E.smooth); }
    hill(len, h) { this.seg(len * .45, h, E.smooth); this.flat(len * .1); this.seg(len * .45, -h, E.smooth); }
    rolling(len, amp) {
      const ph = this.rnd() * 6;
      this.wave(len, amp, t => Math.sin(Math.PI * t) * (0.65 * Math.sin(4 * Math.PI * t + ph) + 0.35 * Math.sin(6.6 * Math.PI * t + ph * 2)));
    }
  }

  /* ---- generators: return finish x ---- */
  function genSX(b, d, len) {
    b.flat(26);
    while (b.x < len) {
      b.mark(); b.flat(b.r(13, 19));
      const p = b.rnd();
      if (p < 0.22) b.whoops(Math.round(b.r(5, 7 + d)), b.r(2.5, 3.0), b.r(0.3, 0.42) + d * 0.03);
      else if (p < 0.5) { const k = Math.round(b.r(2, 3 + (d > 2 ? 1 : 0))); for (let i = 0; i < k; i++) { b.jump(b.r(1.1, 1.4) + d * 0.06, b.r(6.5, 9.5) + d * 0.5); b.flat(b.r(6, 9)); } }
      else if (p < 0.64) b.jump(b.r(1.5, 1.8) + d * 0.05, b.r(11, 14) + d * 0.6);
      else if (p < 0.78) b.table(b.r(1.1, 1.5) + d * 0.06, b.r(5, 8));
      else if (p < 0.9) b.rollers(Math.round(b.r(4, 6)), b.r(5, 6.5), b.r(0.4, 0.6) + d * 0.03);
      else { const h = b.r(1.0, 1.4); b.step(h); b.flat(b.r(9, 13)); b.drop(h); }
    }
    b.flat(14); const f = b.x; b.flat(70); return f;
  }
  function genMX(b, d, len) {
    b.flat(34);
    while (b.x < len) {
      b.mark(); b.flat(b.r(16, 26));
      const p = b.rnd();
      if (p < 0.14) b.whoops(Math.round(b.r(6, 9 + d)), b.r(3.0, 3.5), b.r(0.45, 0.62) + d * 0.03);
      else if (p < 0.34) b.jump(b.r(1.6, 2.1) + d * 0.08, b.r(10, 14) + d * 0.9);
      else if (p < 0.46) b.table(b.r(1.5, 2.0) + d * 0.07, b.r(7, 11));
      else if (p < 0.60) b.hill(b.r(40, 80), b.r(3, 5) + d * 0.5);
      else if (p < 0.72) b.rolling(b.r(50, 90), b.r(1.2, 2.0) + d * 0.15);
      else if (p < 0.82) b.rollers(Math.round(b.r(5, 8)), b.r(6, 8), b.r(0.6, 0.85));
      else if (p < 0.92) { b.hill(b.r(40, 70), -b.r(3, 4.5)); b.flat(10); b.jump(b.r(1.5, 2.0), b.r(10, 14)); }
      else { const h = b.r(1.5, 2.0); b.step(h); b.flat(b.r(12, 18)); b.drop(h); }
    }
    b.flat(16); const f = b.x; b.flat(80); return f;
  }
  function genPit(b, d, len) {
    b.flat(18);
    while (b.x < len) {
      b.flat(b.r(6, 10)); b.mark();
      const p = b.rnd();
      if (p < 0.2) b.whoops(Math.round(b.r(6, 9 + d)), b.r(1.7, 2.0), b.r(0.17, 0.26) + d * 0.015);
      else if (p < 0.44) { const k = Math.round(b.r(1, 3)); for (let i = 0; i < k; i++) { b.jump(b.r(0.5, 0.75) + d * 0.04, b.r(3, 4.5) + d * 0.25); b.flat(b.r(4, 6)); } }
      else if (p < 0.58) b.table(b.r(0.5, 0.75) + d * 0.04, b.r(2.5, 3.5));
      else if (p < 0.74) b.rollers(Math.round(b.r(4, 7)), b.r(3, 4), b.r(0.25, 0.4));
      else if (p < 0.86) b.hill(b.r(14, 26), b.r(1.0, 1.8) + d * 0.15);
      else { const h = b.r(0.5, 0.75); b.step(h); b.flat(b.r(5, 8)); b.drop(h); }
    }
    b.flat(8); const f = b.x; b.flat(50); return f;
  }
  function genComp(b, d, len) {
    b.flat(28);
    while (b.x < len) {
      b.mark(); b.flat(b.r(14, 22));
      const p = b.rnd();
      if (p < 0.15) b.whoops(Math.round(b.r(6, 9)), b.r(2.6, 3.2), b.r(0.35, 0.5) + d * 0.03);
      else if (p < 0.32) b.jump(b.r(1.2, 1.8) + d * 0.06, b.r(7, 11) + d * 0.5);
      else if (p < 0.44) b.table(b.r(1.2, 1.7) + d * 0.05, b.r(5, 9));
      else if (p < 0.56) { b.jump(b.r(1.2, 1.5), b.r(7, 9)); b.flat(b.r(6, 9)); b.jump(b.r(1.4, 1.8) + d * 0.05, b.r(9, 12)); }
      else if (p < 0.68) b.hill(b.r(30, 60), b.r(3, 5.5) + d * 0.4);
      else if (p < 0.78) b.rolling(b.r(40, 70), b.r(1.0, 1.8) + d * 0.12);
      else if (p < 0.88) b.rollers(Math.round(b.r(4, 7)), b.r(5, 7), b.r(0.45, 0.7));
      else if (p < 0.95) { b.hill(b.r(35, 55), -b.r(2.5, 4)); b.flat(9); b.jump(b.r(1.4, 1.8), b.r(9, 12)); }
      else { const h = b.r(1.2, 1.7); b.step(h); b.flat(b.r(10, 15)); b.drop(h); }
    }
    b.flat(14); const f = b.x; b.flat(70); return f;
  }

  /* ---- names ---- */
  const NAMES = {
    sx: ['Apex Dome', 'Redline Stadium', 'Thunder Bowl', 'Neon Arena', 'Ironclad Coliseum', 'Skyline Dome', 'Titan Field', 'Gridiron Run', 'Voltage Arena', 'Capitol Bowl', 'Harbor Dome', 'Summit Stadium', 'Eclipse Arena', 'Granite Coliseum', 'Midnight Dome'],
    mx: ['Dustbowl Ridge', 'Red Mesa MX', 'Pine Hollow', 'Sandy Creek', 'Iron Valley', 'Copper Canyon', 'Bluegrass Raceway', 'Mudslide Ridge', 'Sunset Flats', 'Wolf Run', 'Thunder Ridge', 'Cedar Basin', 'Redwater Hills', 'Timberline MX', 'Falcon Peak'],
    pit: ['Backyard Bash', 'Garage Loop', 'Paddock Pit', 'Mini Mayhem', 'Shed Kickers', 'Farmhouse Flow', 'Gumtree Gully', 'Driveway Derby', 'Orchard Dash', 'Barn Burner'],
    cmp: ['Gully Compound', 'Ranch Compound', 'Quarry Compound', 'Backcountry Compound', 'Sunbaked Compound', 'Hillside Compound', 'Redgum Compound', 'Salvage Yard Compound', 'Mountain Compound', 'Riverbend Compound']
  };
  const GEN = { sx: genSX, mx: genMX, pit: genPit, cmp: genComp };
  const BASELEN = { sx: 520, mx: 900, pit: 380, cmp: 720 };
  const LENSTEP = { sx: 40, mx: 90, pit: 30, cmp: 70 };
  const DIRTS = ['#8a5a36', '#a9502d', '#c9a26a', '#6a4632', '#7d6a5c', '#9a4a2a'];
  const SKY_DAY = [['#4aa3e8', '#d3ecfa'], ['#2f6fb8', '#bcdcf2'], ['#8da2b3', '#dde4e9'], ['#3a5f93', '#f4b98a'], ['#5aa9e6', '#f6e7c8']];

  function hsl(h, s, l) { return 'hsl(' + Math.round(h) + ',' + s + '%,' + l + '%)'; }

  function mkH(arr) {
    const n = arr.length;
    return function (x) {
      if (x < 0) return arr[0] - x * 2.2;
      const f = x / DX, i = Math.floor(f);
      if (i >= n - 1) { const ex = x - (n - 1) * DX; return arr[n - 1] + (ex > 8 ? (ex - 8) * 2.2 : 0); }
      const t = f - i;
      return arr[i] * (1 - t) + arr[i + 1] * t;
    };
  }


  /* ---- 3D layout: corners on flat sections, track width ---- */
  const PARAM = { sx: { half: 4.3, R: 30, berm: 0.9, ext: 18 }, mx: { half: 6.2, R: 40, berm: 0.7, ext: 22 }, pit: { half: 3.4, R: 20, berm: 0.5, ext: 14 }, cmp: { half: 5.2, R: 30, berm: 0.7, ext: 22 } };
  function buildPath(arr, cat, rnd, finishX) {
    const n = arr.length, R0 = PARAM[cat].R, k = new Float32Array(n), ok = new Uint8Array(n), w = 10;
    const bad = new Uint8Array(n);
    for (let i = 4; i < n - 4; i++) if (Math.abs(arr[i + 4] - arr[i - 4]) / 2 > 0.3) bad[i] = 1;
    const dil = Math.round(14 / DX);
    for (let i = 0; i < n; i++) { if (bad[i]) { for (let j = Math.max(0, i - dil); j <= Math.min(n - 1, i + dil); j++) if (!bad[j]) ok[j] = 2; } }
    for (let i = 0; i < n; i++) ok[i] = (bad[i] || ok[i] === 2) ? 0 : 1;
    const sMin = Math.round(30 / DX), sMax = Math.round((finishX - 30) / DX);
    let sgn = rnd() < 0.5 ? 1 : -1, cum = 0, i = sMin;
    while (i < sMax) {
      if (!ok[i]) { i++; continue; }
      let j = i; while (j < sMax && ok[j]) j++;
      const L = (j - i) * DX;
      if (L >= 18 && rnd() < 0.85) {
        let th = 0.5 + rnd() * 1.0;
        const R = R0 * (1 + rnd() * 0.5);
        if (cum > 0.7) sgn = -1; else if (cum < -0.7) sgn = 1;
        if (th * R > L - 7) th = (L - 7) / R;
        if (th >= 0.3) {
          const arc = th * R, st = i + Math.round(((L - arc) / 2) / DX), en = st + Math.round(arc / DX), ramp = Math.round(2.5 / DX);
          for (let q = st; q < en; q++) {
            const e = Math.min(1, (q - st) / ramp, (en - q) / ramp);
            k[q] = sgn / R * (e * e * (3 - 2 * e));
          }
          cum += sgn * th * 0.92; sgn = -sgn;
        }
      }
      i = j + 1;
    }
    const px = new Float32Array(n), pz = new Float32Array(n), tha = new Float32Array(n);
    let x = 0, z = 0, th = 0;
    for (let q = 0; q < n; q++) { px[q] = x; pz[q] = z; tha[q] = th; th += k[q] * DX; const mid = th - k[q] * DX / 2; x += Math.cos(mid) * DX; z += -Math.sin(mid) * DX; }
    // smoothed heights for the landscape beside the track
    let hs = Float32Array.from(arr);
    for (let pass = 0; pass < 2; pass++) { const t = new Float32Array(n); for (let q = 0; q < n; q++) { let a = 0, c = 0; for (let j = Math.max(0, q - 32); j <= Math.min(n - 1, q + 32); j += 2) { a += hs[j]; c++; } t[q] = a / c; } hs = t; }
    return { k, px, pz, th: tha, hs };
  }
  function mkPath(P, n) {
    const last = n - 1;
    return {
      pos(s) {
        const f = s / DX;
        if (f <= 0) { const t = P.th[0]; return { x: P.px[0] + Math.cos(t) * s, z: P.pz[0] - Math.sin(t) * s, th: t }; }
        if (f >= last) { const t = P.th[last], e = s - last * DX; return { x: P.px[last] + Math.cos(t) * e, z: P.pz[last] - Math.sin(t) * e, th: t }; }
        const i = Math.floor(f), u = f - i;
        return { x: P.px[i] * (1 - u) + P.px[i + 1] * u, z: P.pz[i] * (1 - u) + P.pz[i + 1] * u, th: P.th[i] * (1 - u) + P.th[i + 1] * u };
      },
      curv(s) { const f = s / DX; if (f <= 0 || f >= last) return 0; const i = Math.floor(f); return P.k[i]; },
      hs(s) { const f = clampN(s / DX, 0, last - 1), i = Math.floor(f), u = f - i; return P.hs[i] * (1 - u) + P.hs[i + 1] * u; }
    };
  }
  function clampN(v, a, b) { return v < a ? a : v > b ? b : v; }

  const list = [];
  let id = 0;
  ['sx', 'mx', 'pit', 'cmp'].forEach(cat => {
    const names = NAMES[cat];
    names.forEach((name, idx) => {
      const seed = 1000 + id * 7919;
      const rnd = mulberry(seed);
      const d = 1 + Math.floor(idx * 5 / names.length);              // difficulty 1..5
      const len = BASELEN[cat] + d * LENSTEP[cat] + rnd() * LENSTEP[cat];
      const b = new Builder(rnd);
      const finishX = GEN[cat](b, d, len);
      const hue = rnd() * 360;
      const theme = { dirt: DIRTS[Math.floor(rnd() * DIRTS.length)], accent: hsl(hue, 90, 58), hue: hue, variant: Math.floor(rnd() * 5) };
      if (cat === 'sx') theme.sky = [hsl(hue, 40, 6), hsl(hue, 45, 15)];
      else theme.sky = SKY_DAY[theme.variant % SKY_DAY.length];
      const arr = Float32Array.from(b.h);
      let mn = 1e9, mx = -1e9; for (let i = 0; i < arr.length; i++) { if (arr[i] < mn) mn = arr[i]; if (arr[i] > mx) mx = arr[i]; }
      const P = buildPath(arr, cat, mulberry(seed + 99), finishX), pa = mkPath(P, arr.length), pr = PARAM[cat];
      list.push({
        half: pr.half, bermH: pr.berm, ext: pr.ext, pathK: P.k, pathX: P.px, pathZ: P.pz, pathTh: P.th,
        pos: pa.pos, curv: pa.curv, hsF: pa.hs,
        id: cat + '-' + (idx + 1), n: id, cat, name, d, theme,
        len: Math.round(finishX - 14), startX: 14, finishX,
        cps: [20].concat(b.cps.filter(c => c < finishX - 40), [finishX - 12]),
        h: mkH(arr), arr, minH: mn, maxH: mx
      });
      id++;
    });
  });

  window.TRACKS = { list, DX };
})();
