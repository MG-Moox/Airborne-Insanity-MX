/* Dirt Rush MX - tiny WebGL1 engine (no dependencies) */
(function () {
  'use strict';

  /* ---------------- math (column-major mat4) ---------------- */
  const M = {
    ident() { return new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]); },
    mul(a, b) {
      const o = new Float32Array(16);
      for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) {
        o[c * 4 + r] = a[r] * b[c * 4] + a[4 + r] * b[c * 4 + 1] + a[8 + r] * b[c * 4 + 2] + a[12 + r] * b[c * 4 + 3];
      }
      return o;
    },
    chain() { let m = arguments[0]; for (let i = 1; i < arguments.length; i++) m = M.mul(m, arguments[i]); return m; },
    T(x, y, z) { const m = M.ident(); m[12] = x; m[13] = y; m[14] = z; return m; },
    S(x, y, z) { const m = M.ident(); m[0] = x; m[5] = y; m[10] = z; return m; },
    Rx(a) { const c = Math.cos(a), s = Math.sin(a), m = M.ident(); m[5] = c; m[6] = s; m[9] = -s; m[10] = c; return m; },
    Ry(a) { const c = Math.cos(a), s = Math.sin(a), m = M.ident(); m[0] = c; m[2] = -s; m[8] = s; m[10] = c; return m; },
    Rz(a) { const c = Math.cos(a), s = Math.sin(a), m = M.ident(); m[0] = c; m[1] = s; m[4] = -s; m[5] = c; return m; },
    persp(fovy, asp, n, f) {
      const t = 1 / Math.tan(fovy / 2), m = new Float32Array(16);
      m[0] = t / asp; m[5] = t; m[10] = (f + n) / (n - f); m[11] = -1; m[14] = 2 * f * n / (n - f); return m;
    },
    ortho(l, r, b, t, n, f) { const m = new Float32Array(16); m[0] = 2 / (r - l); m[5] = 2 / (t - b); m[10] = -2 / (f - n); m[12] = -(r + l) / (r - l); m[13] = -(t + b) / (t - b); m[14] = -(f + n) / (f - n); m[15] = 1; return m; },
    lookAt(e, t, up) {
      let zx = e[0] - t[0], zy = e[1] - t[1], zz = e[2] - t[2], l = Math.hypot(zx, zy, zz) || 1; zx /= l; zy /= l; zz /= l;
      let xx = up[1] * zz - up[2] * zy, xy = up[2] * zx - up[0] * zz, xz = up[0] * zy - up[1] * zx; l = Math.hypot(xx, xy, xz) || 1; xx /= l; xy /= l; xz /= l;
      const yx = zy * xz - zz * xy, yy = zz * xx - zx * xz, yz = zx * xy - zy * xx;
      return new Float32Array([xx, yx, zx, 0, xy, yy, zy, 0, xz, yz, zz, 0, -(xx * e[0] + xy * e[1] + xz * e[2]), -(yx * e[0] + yy * e[1] + yz * e[2]), -(zx * e[0] + zy * e[1] + zz * e[2]), 1]);
    },
    // matrix with local Y axis pointing from a to b, centred between them, scaled (sx, |ab|, sz); local Z kept near world Z
    between(a, b, sx, sz) {
      const dx = b[0] - a[0], dy = b[1] - a[1], dz = b[2] - a[2], len = Math.hypot(dx, dy, dz) || 1e-6;
      const yx = dx / len, yy = dy / len, yz = dz / len;
      let xx = yy * 1 - yz * 0, xy = yz * 0 - yx * 1, xz = 0;      // cross(y, (0,0,1))
      let l = Math.hypot(xx, xy, xz);
      if (l < 1e-5) { xx = 1; xy = 0; xz = 0; l = 1; }
      xx /= l; xy /= l; xz /= l;
      const zx = xy * yz - xz * yy, zy = xz * yx - xx * yz, zz = xx * yy - xy * yx;
      return new Float32Array([xx * sx, xy * sx, xz * sx, 0, yx * len, yy * len, yz * len, 0, zx * sz, zy * sz, zz * sz, 0, (a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2, 1]);
    },
    normalMat(m) {
      const ax = m[0], ay = m[1], az = m[2], bx = m[4], by = m[5], bz = m[6], cx = m[8], cy = m[9], cz = m[10];
      const c0 = [by * cz - bz * cy, bz * cx - bx * cz, bx * cy - by * cx];
      const c1 = [cy * az - cz * ay, cz * ax - cx * az, cx * ay - cy * ax];
      const c2 = [ay * bz - az * by, az * bx - ax * bz, ax * by - ay * bx];
      const det = ax * c0[0] + ay * c0[1] + az * c0[2], id = Math.abs(det) > 1e-9 ? 1 / det : 1;
      return new Float32Array([c0[0] * id, c0[1] * id, c0[2] * id, c1[0] * id, c1[1] * id, c1[2] * id, c2[0] * id, c2[1] * id, c2[2] * id]);
    }
  };
  function lin(hex) {                                   // '#rrggbb' or 'hsl(...)' -> linear rgb
    let r, g, b;
    if (hex[0] === '#') { const n = parseInt(hex.slice(1), 16); r = (n >> 16) & 255; g = (n >> 8) & 255; b = n & 255; }
    else if (hex.indexOf('hsl') === 0) {
      const m = /hsl\((\d+),(\d+)%,(\d+)%\)/.exec(hex.replace(/\s/g, '')); const h = +m[1] / 360, s = +m[2] / 100, l = +m[3] / 100;
      const f = n => { const k = (n + h * 12) % 12, a = s * Math.min(l, 1 - l); return l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1)); };
      r = f(0) * 255; g = f(8) * 255; b = f(4) * 255;
    } else if (hex.indexOf('rgb') === 0) { const m = /rgb\((\d+),(\d+),(\d+)\)/.exec(hex.replace(/\s/g, '')); r = +m[1]; g = +m[2]; b = +m[3]; }
    else { r = g = b = 128; }
    return [Math.pow(r / 255, 2.2), Math.pow(g / 255, 2.2), Math.pow(b / 255, 2.2)];
  }
  function rgb(hex) { const l = lin(hex); return [Math.pow(l[0], 1 / 2.2), Math.pow(l[1], 1 / 2.2), Math.pow(l[2], 1 / 2.2)]; }   // sRGB 0..1

  /* ---------------- geometry ---------------- */
  class Geo {
    constructor() { this.v = []; this.i = []; this.n = 0; }
    // shape: {p:[x,y,z...], n:[...], c:[...] (optional), i:[...]}
    add(shape, m, col) {
      const nm = M.normalMat(m), c = col ? rgb(col) : [1, 1, 1], p = shape.p, nn = shape.n, cc = shape.c, base = this.n;
      const cnt = p.length / 3;
      for (let k = 0; k < cnt; k++) {
        const x = p[k * 3], y = p[k * 3 + 1], z = p[k * 3 + 2];
        const wx = m[0] * x + m[4] * y + m[8] * z + m[12], wy = m[1] * x + m[5] * y + m[9] * z + m[13], wz = m[2] * x + m[6] * y + m[10] * z + m[14];
        const nx = nn[k * 3], ny = nn[k * 3 + 1], nz = nn[k * 3 + 2];
        let ex = nm[0] * nx + nm[3] * ny + nm[6] * nz, ey = nm[1] * nx + nm[4] * ny + nm[7] * nz, ez = nm[2] * nx + nm[5] * ny + nm[8] * nz;
        const l = Math.hypot(ex, ey, ez) || 1;
        const sh = cc ? cc[k] : 1;
        this.v.push(wx, wy, wz, ex / l, ey / l, ez / l, c[0] * sh, c[1] * sh, c[2] * sh);
      }
      for (let k = 0; k < shape.i.length; k++) this.i.push(shape.i[k] + base);
      this.n += cnt;
    }
    raw(px, py, pz, nx, ny, nz, r, g, b) { this.v.push(px, py, pz, nx, ny, nz, r, g, b); return this.n++; }
    tri(a, b, c) { this.i.push(a, b, c); }
  }
  const SH = {};
  SH.box = (function () {
    const p = [], n = [], i = [];
    const F = [[[0, 0, 1], [-1, -1, 1], [1, -1, 1], [1, 1, 1], [-1, 1, 1]], [[0, 0, -1], [1, -1, -1], [-1, -1, -1], [-1, 1, -1], [1, 1, -1]],
    [[1, 0, 0], [1, -1, 1], [1, -1, -1], [1, 1, -1], [1, 1, 1]], [[-1, 0, 0], [-1, -1, -1], [-1, -1, 1], [-1, 1, 1], [-1, 1, -1]],
    [[0, 1, 0], [-1, 1, 1], [1, 1, 1], [1, 1, -1], [-1, 1, -1]], [[0, -1, 0], [-1, -1, -1], [1, -1, -1], [1, -1, 1], [-1, -1, 1]]];
    F.forEach(f => { const b = p.length / 3; for (let k = 1; k <= 4; k++) { p.push(f[k][0] * 0.5, f[k][1] * 0.5, f[k][2] * 0.5); n.push(f[0][0], f[0][1], f[0][2]); } i.push(b, b + 1, b + 2, b, b + 2, b + 3); });
    return { p, n, i };
  })();
  SH.cyl = function (seg, r1, caps) {        // axis Y, height 1 (y -0.5..0.5), bottom radius 0.5*? -> radius 0.5 at bottom, 0.5*r1 at top
    seg = seg || 14; r1 = r1 == null ? 1 : r1;
    const p = [], n = [], i = [], rb = 0.5, rt = 0.5 * r1, slope = (rb - rt);
    for (let k = 0; k <= seg; k++) {
      const a = k / seg * Math.PI * 2, c = Math.cos(a), s = Math.sin(a);
      const nl = Math.hypot(1, slope), nx = c / nl, ny = slope / nl, nz = s / nl;
      p.push(c * rb, -0.5, s * rb, c * rt, 0.5, s * rt); n.push(nx, ny, nz, nx, ny, nz);
    }
    for (let k = 0; k < seg; k++) { const a = k * 2; i.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); }
    if (caps !== false) {
      [[-0.5, rb, -1], [0.5, rt, 1]].forEach(cp => {
        const b = p.length / 3; p.push(0, cp[0], 0); n.push(0, cp[2], 0);
        for (let k = 0; k <= seg; k++) { const a = k / seg * Math.PI * 2; p.push(Math.cos(a) * cp[1], cp[0], Math.sin(a) * cp[1]); n.push(0, cp[2], 0); }
        for (let k = 0; k < seg; k++) { if (cp[2] > 0) i.push(b, b + 2 + k, b + 1 + k); else i.push(b, b + 1 + k, b + 2 + k); }
      });
    }
    return { p, n, i };
  };
  SH.sph = function (lat, lon) {
    lat = lat || 10; lon = lon || 14; const p = [], n = [], i = [];
    for (let a = 0; a <= lat; a++) { const th = a / lat * Math.PI, st = Math.sin(th), ct = Math.cos(th); for (let b = 0; b <= lon; b++) { const ph = b / lon * Math.PI * 2; const x = st * Math.cos(ph), z = st * Math.sin(ph); p.push(x * 0.5, ct * 0.5, z * 0.5); n.push(x, ct, z); } }
    for (let a = 0; a < lat; a++) for (let b = 0; b < lon; b++) { const q = a * (lon + 1) + b; i.push(q, q + 1, q + lon + 1, q + 1, q + lon + 2, q + lon + 1); }
    return { p, n, i };
  };
  // torus in XY plane (axis Z). colour shading alternates per tread block
  SH.torus = function (R, r, segMaj, segMin, blocks) {
    const p = [], n = [], c = [], i = [];
    for (let a = 0; a <= segMaj; a++) {
      const th = a / segMaj * Math.PI * 2, ct = Math.cos(th), st = Math.sin(th);
      const shade = blocks ? ((Math.floor(a / segMaj * blocks * 2) % 2) ? 1.0 : 0.62) : 1;
      for (let b = 0; b <= segMin; b++) {
        const ph = b / segMin * Math.PI * 2, cp = Math.cos(ph), sp = Math.sin(ph);
        const kn = blocks && (b > segMin * 0.2 && b < segMin * 0.8) ? 1 : 0.85;          // knobs on tread
        const rr = r * (blocks ? (1 + (shade > 0.9 && kn === 1 ? 0.16 : 0)) : 1);
        p.push((R + rr * cp) * ct, (R + rr * cp) * st, rr * sp); n.push(cp * ct, cp * st, sp); c.push(shade * (0.8 + 0.2 * kn));
      }
    }
    for (let a = 0; a < segMaj; a++) for (let b = 0; b < segMin; b++) { const q = a * (segMin + 1) + b; i.push(q, q + segMin + 1, q + 1, q + 1, q + segMin + 1, q + segMin + 2); }
    return { p, n, c, i };
  };

  /* ---------------- GL ---------------- */
  let gl, cvs, ext32, progMain, progSky, progPts, progSh, W = 1, H = 1, shFB = null, shTex = null, inShadow = false, shadowOn = false, curLVP = null;
  const SMS = 2048;
  const U = {};
  const VS = 'attribute vec3 aPos;attribute vec3 aNor;attribute vec3 aCol;uniform mat4 uVP;uniform mat4 uModel;uniform mat3 uNM;uniform mat4 uLVP;varying vec3 vN;varying vec3 vC;varying vec3 vW;varying vec4 vLP;void main(){vec4 w=uModel*vec4(aPos,1.0);vW=w.xyz;vN=uNM*aNor;vC=aCol;vLP=uLVP*w;gl_Position=uVP*w;}';
  const FS = [
    'precision highp float;',
    'varying vec3 vN;varying vec3 vC;varying vec3 vW;varying vec4 vLP;',
    'uniform vec3 uTint,uSunDir,uSunCol,uSkyCol,uGndCol,uFogCol,uCam;uniform float uFogDen,uMode,uGrain,uAlpha,uSpec,uTime,uShadow,uTexel;uniform sampler2D uSM;',
    'float unpackD(vec4 c){return dot(c,vec4(1.0,1.0/255.0,1.0/65025.0,1.0/16581375.0));}',
    'float shadowF(float ndl){if(uShadow<0.5)return 1.;vec3 p=vLP.xyz/vLP.w*0.5+0.5;if(p.x<0.||p.x>1.||p.y<0.||p.y>1.||p.z>1.)return 1.;',
    ' float bias=0.0009+0.0026*(1.-ndl);float s=0.;for(int i=-1;i<=1;i++){for(int j=-1;j<=1;j++){float d=unpackD(texture2D(uSM,p.xy+vec2(float(i),float(j))*uTexel*1.3));s+=(p.z-bias>d)?0.:1.;}}s/=9.;',
    ' float e=max(abs(p.x-0.5),abs(p.y-0.5))*2.;return mix(s,1.,smoothstep(0.82,1.,e));}',
    'float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}',
    'float vn(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1.,0.)),f.x),mix(hash(i+vec2(0.,1.)),hash(i+vec2(1.,1.)),f.x),f.y);}',
    'void main(){',
    ' vec3 base=pow(vC*uTint,vec3(2.2));vec3 N=normalize(vN);',
    ' float dcam=length(uCam-vW);',
    ' if(uGrain>0.){float nf=1.-smoothstep(8.,38.,dcam);float n=vn(vW.xz*1.7)*0.4+vn(vW.xz*6.3)*0.3+vn(vW.xz*27.)*0.18+vn(vW.xz*90.)*0.12*nf+vn(vW.xz*210.)*0.08*nf;base*=0.7+0.6*n;',
    '  N=normalize(N+vec3(vn(vW.xz*5.+7.)-0.5,0.,vn(vW.xz*5.+19.)-0.5)*0.6*uGrain);}',
    ' vec3 col;',
    ' if(uMode>1.5&&uMode<2.5){vec2 cell=floor(vec2(vW.x+vW.z,vW.y*1.3)*3.4);float h=hash(cell);float h2=hash(cell+13.7);',
    '  vec3 pc=vec3(0.18+0.5*h2,0.15+0.4*hash(cell+3.1),0.15+0.45*hash(cell+8.3));if(h<0.3)pc=vec3(0.03);',
    '  vec2 f=fract(vec2(vW.x+vW.z,vW.y*1.3)*3.4);float dot_=smoothstep(0.55,0.35,length(f-0.5));',
    '  base=mix(vec3(0.015),pow(pc,vec3(2.2)),dot_);base=mix(base,vec3(0.075,0.065,0.08),smoothstep(22.,60.,length(uCam-vW)));',
    '  col=base*(0.35+uSunCol*0.3)+base*0.9;}',
    ' else if(uMode>0.5&&uMode<1.5){col=base;}',
    ' else{float ndl=max(dot(N,uSunDir),0.);vec3 amb=mix(uGndCol,uSkyCol,N.y*0.5+0.5);col=base*(amb+uSunCol*ndl*shadowF(ndl));',
    '  vec3 V=normalize(uCam-vW);vec3 Hh=normalize(V+uSunDir);col+=uSunCol*pow(max(dot(N,Hh),0.),40.)*uSpec;',
    '  col+=uSkyCol*pow(1.-max(dot(N,V),0.),3.)*0.08*uSpec;}',
    ' float d=length(uCam-vW);float f=1.-exp(-pow(d*uFogDen,1.5));col=mix(col,uFogCol,clamp(f,0.,1.));',
    ' col=vec3(1.)-exp(-col*1.25);col=pow(col,vec3(0.4545));gl_FragColor=vec4(col,uAlpha);}'
  ].join('\n');
  const SH_VS = 'attribute vec3 aPos;uniform mat4 uLVP;uniform mat4 uModel;void main(){gl_Position=uLVP*uModel*vec4(aPos,1.0);}';
  const SH_FS = 'precision highp float;void main(){vec4 e=vec4(1.,255.,65025.,16581375.)*gl_FragCoord.z;e=fract(e);e-=e.yzww*vec4(1./255.,1./255.,1./255.,0.);gl_FragColor=e;}';
  function initShadow() {
    shTex = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, shTex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, SMS, SMS, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    const rb = gl.createRenderbuffer(); gl.bindRenderbuffer(gl.RENDERBUFFER, rb); gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT16, SMS, SMS);
    shFB = gl.createFramebuffer(); gl.bindFramebuffer(gl.FRAMEBUFFER, shFB);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, shTex, 0); gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, rb);
    if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) shFB = null;
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  }
  function shadowBegin(lvp) {
    if (!shFB) return false;
    curLVP = lvp; inShadow = true;
    gl.bindFramebuffer(gl.FRAMEBUFFER, shFB); gl.viewport(0, 0, SMS, SMS);
    gl.clearColor(1, 1, 1, 1); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.useProgram(progSh); gl.uniformMatrix4fv(U.h.uLVP, false, lvp);
    gl.cullFace(gl.FRONT); return true;
  }
  function shadowEnd() {
    inShadow = false; shadowOn = true;
    gl.bindFramebuffer(gl.FRAMEBUFFER, null); gl.viewport(0, 0, W, H); gl.cullFace(gl.BACK); gl.useProgram(progMain);
  }

  const PO_VS = 'attribute vec2 aP;varying vec2 vUV;void main(){vUV=aP*0.5+0.5;gl_Position=vec4(aP,0.0,1.0);}';
  const PO_FS = [
    'precision highp float;varying vec2 vUV;uniform sampler2D uTex;uniform vec2 uPx;uniform float uSpeed,uBloom,uTime,uFx;',
    'vec3 T(vec2 uv){return texture2D(uTex,uv).rgb;}',
    'float L(vec3 c){return dot(c,vec3(0.299,0.587,0.114));}',
    'float hash(vec2 p){return fract(sin(dot(p,vec2(12.9898,78.233)))*43758.5453);}',
    'void main(){',
    ' vec2 c=vUV-0.5;float r=length(c);',
    ' vec3 col=T(vUV);',
    ' if(uFx>0.5){',
    '  float l0=L(col),l1=L(T(vUV+vec2(uPx.x,0.))),l2=L(T(vUV-vec2(uPx.x,0.))),l3=L(T(vUV+vec2(0.,uPx.y))),l4=L(T(vUV-vec2(0.,uPx.y)));',
    '  float mx=max(l0,max(max(l1,l2),max(l3,l4))),mn=min(l0,min(min(l1,l2),min(l3,l4)));',
    '  if(mx-mn>0.06){vec3 a=(T(vUV+vec2(uPx.x,0.))+T(vUV-vec2(uPx.x,0.))+T(vUV+vec2(0.,uPx.y))+T(vUV-vec2(0.,uPx.y)))*0.25;col=mix(col,(col+a)*0.5,0.85);}',
    '  float amt=uSpeed*0.034*smoothstep(0.15,0.8,r);',
    '  if(amt>0.001){vec3 acc=col;for(int i=1;i<7;i++){acc+=T(vUV-c*amt*float(i)/6.);}col=acc/7.;}',
    '  vec3 b=vec3(0.);',
    '  for(int i=0;i<8;i++){float a=float(i)*0.7854;vec2 o=vec2(cos(a),sin(a));b+=max(T(vUV+o*uPx*7.)-0.78,0.)+max(T(vUV+o*uPx*18.)-0.78,0.)*0.8;}',
    '  col+=b/12.*uBloom;',
    ' }',
    ' col=mix(col,col*col*(3.-2.*col),0.32);',
    ' float g=L(col);col=mix(vec3(g),col,1.12);',
    ' col*=vec3(1.02,1.0,0.97);',
    ' col*=1.-0.38*smoothstep(0.38,1.0,r*1.45);',
    ' col+=(hash(vUV/uPx+uTime)-0.5)*0.022;',
    ' gl_FragColor=vec4(col,1.);}'
  ].join('\n');
  let progPost, sceneFB = null, sceneTex = null, sceneRB = null, postOn = true, postAttr = true;
  function makeScene() {
    if (sceneTex) { gl.deleteTexture(sceneTex); gl.deleteRenderbuffer(sceneRB); gl.deleteFramebuffer(sceneFB); }
    sceneTex = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, sceneTex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, W, H, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    sceneRB = gl.createRenderbuffer(); gl.bindRenderbuffer(gl.RENDERBUFFER, sceneRB); gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT16, W, H);
    sceneFB = gl.createFramebuffer(); gl.bindFramebuffer(gl.FRAMEBUFFER, sceneFB);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, sceneTex, 0); gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, sceneRB);
    if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) { sceneFB = null; }
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  }
  function endFrame(speed) {
    if (!sceneFB) return;
    gl.bindFramebuffer(gl.FRAMEBUFFER, null); gl.viewport(0, 0, W, H);
    gl.disable(gl.DEPTH_TEST); gl.disable(gl.CULL_FACE);
    gl.useProgram(progPost);
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, sceneTex);
    gl.uniform1i(gl.getUniformLocation(progPost, 'uTex'), 0); gl.uniform2f(gl.getUniformLocation(progPost, 'uPx'), 1 / W, 1 / H);
    gl.uniform1f(gl.getUniformLocation(progPost, 'uSpeed'), speed); gl.uniform1f(gl.getUniformLocation(progPost, 'uBloom'), 0.6);
    gl.uniform1f(gl.getUniformLocation(progPost, 'uTime'), (time * 7.31) % 10); gl.uniform1f(gl.getUniformLocation(progPost, 'uFx'), postOn ? 1 : 0);
    gl.bindBuffer(gl.ARRAY_BUFFER, skyBuf); gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    gl.enable(gl.DEPTH_TEST); gl.enable(gl.CULL_FACE); gl.useProgram(progMain);
  }
  // dynamic geometry (decals such as tyre tracks): interleaved pos/nor/col floats + indices
  let dynVB = null, dynIB = null;
  function drawDynamic(verts, idx, tint, o) {
    if (!idx.length) return;
    o = o || {};
    if (!dynVB) { dynVB = gl.createBuffer(); dynIB = gl.createBuffer(); }
    gl.bindBuffer(gl.ARRAY_BUFFER, dynVB); gl.bufferData(gl.ARRAY_BUFFER, verts, gl.DYNAMIC_DRAW);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, dynIB); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, idx, gl.DYNAMIC_DRAW);
    const u = U.m;
    gl.uniformMatrix4fv(u.uModel, false, I3); gl.uniformMatrix3fv(u.uNM, false, NI); gl.uniform3fv(u.uTint, tint || [1, 1, 1]);
    gl.uniform1f(u.uMode, o.mode || 0); gl.uniform1f(u.uGrain, 0); gl.uniform1f(u.uAlpha, o.alpha == null ? 1 : o.alpha); gl.uniform1f(u.uSpec, 0);
    gl.enableVertexAttribArray(0); gl.enableVertexAttribArray(1); gl.enableVertexAttribArray(2);
    gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 36, 0); gl.vertexAttribPointer(1, 3, gl.FLOAT, false, 36, 12); gl.vertexAttribPointer(2, 3, gl.FLOAT, false, 36, 24);
    gl.drawElements(gl.TRIANGLES, idx.length, gl.UNSIGNED_INT, 0);
  }
  const SKY_VS = 'attribute vec2 aP;varying vec2 vP;void main(){vP=aP;gl_Position=vec4(aP,1.0,1.0);}';
  const SKY_FS = [
    'precision highp float;varying vec2 vP;',
    'uniform vec3 uFwd,uRight,uUp,uTop,uHor,uGnd,uSunDir,uSunCol;uniform float uTanH,uAsp,uNight,uCloud,uTime;',
    'float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}',
    'float vn(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1.,0.)),f.x),mix(hash(i+vec2(0.,1.)),hash(i+vec2(1.,1.)),f.x),f.y);}',
    'float fbm(vec2 p){return vn(p)*0.5+vn(p*2.03)*0.25+vn(p*4.1)*0.125+vn(p*8.3)*0.0625;}',
    'void main(){vec3 d=normalize(uFwd+uRight*(vP.x*uTanH*uAsp)+uUp*(vP.y*uTanH));',
    ' float t=d.y;vec3 col=mix(uHor,uTop,pow(clamp(t,0.,1.),0.55));',
    ' if(t<0.)col=mix(uHor,uGnd,clamp(-t*6.,0.,1.));',
    ' float sd=max(dot(d,uSunDir),0.);col+=uSunCol*(pow(sd,900.)*3.+pow(sd,10.)*0.25+pow(sd,3.)*0.05);',
    ' if(uCloud>0.&&t>0.02){vec2 uv=d.xz/(t+0.15)*1.4+vec2(uTime*0.004,0.);float c=fbm(uv*1.3);c=smoothstep(0.5,0.85,c)*uCloud*smoothstep(0.02,0.25,t);col=mix(col,mix(vec3(1.),uHor*1.1,0.25)*(0.7+0.5*uSunCol.r*0.2),c*0.85);}',
    ' if(uNight>0.&&t>0.){float s=hash(floor(d.xz/(t+0.3)*140.));col+=vec3(step(0.9965,s))*uNight*0.8*smoothstep(0.1,0.5,t);}',
    ' col=vec3(1.)-exp(-col*1.25);col=pow(col,vec3(0.4545));gl_FragColor=vec4(col,1.);}'
  ].join('\n');
  const PT_VS = 'attribute vec3 aPos;attribute vec2 aSA;uniform mat4 uVP;uniform float uScale;varying float vA;void main(){vec4 p=uVP*vec4(aPos,1.0);gl_Position=p;gl_PointSize=min(160.,aSA.x*uScale/max(p.w,0.1));vA=aSA.y;}';
  const PT_FS = 'precision mediump float;varying float vA;uniform vec3 uCol;void main(){float d=length(gl_PointCoord-0.5)*2.;float a=smoothstep(1.,0.2,d)*vA;if(a<0.01)discard;gl_FragColor=vec4(uCol,a);}';

  function compile(vs, fs, attrs) {
    const mk = (t, s) => { const sh = gl.createShader(t); gl.shaderSource(sh, s); gl.compileShader(sh); if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(sh)); return sh; };
    const p = gl.createProgram(); gl.attachShader(p, mk(gl.VERTEX_SHADER, vs)); gl.attachShader(p, mk(gl.FRAGMENT_SHADER, fs)); (attrs || []).forEach((a, i) => gl.bindAttribLocation(p, i, a)); gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
    return p;
  }
  function locs(p, names) { const o = {}; names.forEach(n => { o[n] = gl.getUniformLocation(p, n); }); return o; }

  let skyBuf, ptBuf, ptData = new Float32Array(0), ptCap = 0;
  const env = { sunDir: [0.4, 0.7, 0.3], sunCol: [1, 1, 1], skyCol: [0.3, 0.4, 0.6], gndCol: [0.2, 0.15, 0.1], fogCol: [0.6, 0.7, 0.8], fogDen: 0.002, top: [0.2, 0.4, 0.8], hor: [0.7, 0.8, 0.9], gnd: [0.3, 0.3, 0.3], night: 0, cloud: 0.6 };
  let time = 0;

  function init(canvas) {
    cvs = canvas;
    gl = canvas.getContext('webgl', { antialias: true, alpha: false, powerPreference: 'high-performance' }) || canvas.getContext('experimental-webgl');
    if (!gl) throw new Error('WebGL is not available');
    ext32 = gl.getExtension('OES_element_index_uint');
    progMain = compile(VS, FS, ['aPos', 'aNor', 'aCol']);
    U.m = locs(progMain, ['uVP', 'uModel', 'uNM', 'uTint', 'uSunDir', 'uSunCol', 'uSkyCol', 'uGndCol', 'uFogCol', 'uCam', 'uFogDen', 'uMode', 'uGrain', 'uAlpha', 'uSpec', 'uTime', 'uLVP', 'uShadow', 'uTexel', 'uSM']);
    progSky = compile(SKY_VS, SKY_FS, ['aP']);
    U.s = locs(progSky, ['uFwd', 'uRight', 'uUp', 'uTop', 'uHor', 'uGnd', 'uSunDir', 'uSunCol', 'uTanH', 'uAsp', 'uNight', 'uCloud', 'uTime']);
    progPts = compile(PT_VS, PT_FS, ['aPos', 'aSA']);
    progSh = compile(SH_VS, SH_FS, ['aPos']);
    progPost = compile(PO_VS, PO_FS, ['aP']);
    U.h = locs(progSh, ['uLVP', 'uModel']);
    initShadow();
    U.p = locs(progPts, ['uVP', 'uScale', 'uCol']);
    skyBuf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, skyBuf); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    ptBuf = gl.createBuffer();
    gl.enable(gl.DEPTH_TEST); gl.enable(gl.CULL_FACE); gl.cullFace(gl.BACK);
    // shared unit shapes
    G.box = mesh(SH.box); G.cyl = mesh(SH.cyl(14, 1)); G.cone = mesh(SH.cyl(10, 0)); G.cyl8 = mesh(SH.cyl(8, 1)); G.sph = mesh(SH.sph(10, 14));
  }
  function resize(w, h, dpr) {
    W = Math.max(2, Math.floor(w * dpr)); H = Math.max(2, Math.floor(h * dpr));
    cvs.width = W; cvs.height = H; cvs.style.width = w + 'px'; cvs.style.height = h + 'px'; gl.viewport(0, 0, W, H); makeScene();
  }

  function upload(geo) {
    const vb = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, vb); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(geo.v), gl.STATIC_DRAW);
    const ib = gl.createBuffer(); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ib); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint32Array(geo.i), gl.STATIC_DRAW);
    return { vb, ib, count: geo.i.length };
  }
  function mesh(shape) { const g = new Geo(); g.add(shape, M.ident(), null); return upload(g); }
  function free(m) { if (!m) return; gl.deleteBuffer(m.vb); gl.deleteBuffer(m.ib); }

  const I3 = M.ident(), NI = M.normalMat(I3);
  let curVP = null;
  function begin(vp, cam) {
    curVP = vp;
    gl.bindFramebuffer(gl.FRAMEBUFFER, sceneFB); gl.viewport(0, 0, W, H);
    gl.clearColor(0, 0, 0, 1); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.useProgram(progMain);
    const u = U.m;
    gl.uniformMatrix4fv(u.uVP, false, vp);
    gl.uniform3fv(u.uSunDir, env.sunDir); gl.uniform3fv(u.uSunCol, env.sunCol); gl.uniform3fv(u.uSkyCol, env.skyCol); gl.uniform3fv(u.uGndCol, env.gndCol);
    gl.uniform3fv(u.uFogCol, env.fogCol); gl.uniform3fv(u.uCam, cam); gl.uniform1f(u.uFogDen, env.fogDen); gl.uniform1f(u.uTime, time);
    gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, shTex); gl.uniform1i(u.uSM, 1); gl.activeTexture(gl.TEXTURE0);
    gl.uniform1f(u.uShadow, shadowOn && curLVP ? 1 : 0); gl.uniform1f(u.uTexel, 1 / SMS); if (curLVP) gl.uniformMatrix4fv(u.uLVP, false, curLVP);
  }
  function drawSky(cam) {
    gl.disable(gl.DEPTH_TEST); gl.disable(gl.CULL_FACE);
    gl.useProgram(progSky); const u = U.s;
    gl.uniform3fv(u.uFwd, cam.fwd); gl.uniform3fv(u.uRight, cam.right); gl.uniform3fv(u.uUp, cam.up);
    gl.uniform3fv(u.uTop, env.top); gl.uniform3fv(u.uHor, env.hor); gl.uniform3fv(u.uGnd, env.gnd); gl.uniform3fv(u.uSunDir, env.sunDir); gl.uniform3fv(u.uSunCol, env.sunCol);
    gl.uniform1f(u.uTanH, cam.tanH); gl.uniform1f(u.uAsp, cam.asp); gl.uniform1f(u.uNight, env.night); gl.uniform1f(u.uCloud, env.cloud); gl.uniform1f(u.uTime, time);
    gl.bindBuffer(gl.ARRAY_BUFFER, skyBuf); const a = gl.getAttribLocation(progSky, 'aP');
    gl.enableVertexAttribArray(a); gl.vertexAttribPointer(a, 2, gl.FLOAT, false, 0, 0); gl.drawArrays(gl.TRIANGLES, 0, 3); gl.disableVertexAttribArray(a);
    gl.enable(gl.DEPTH_TEST); gl.enable(gl.CULL_FACE);
    gl.useProgram(progMain);
  }
  let aLoc = null;
  function bindMesh(m) {
    if (!aLoc) aLoc = { p: gl.getAttribLocation(progMain, 'aPos'), n: gl.getAttribLocation(progMain, 'aNor'), c: gl.getAttribLocation(progMain, 'aCol') };
    gl.bindBuffer(gl.ARRAY_BUFFER, m.vb); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, m.ib);
    gl.enableVertexAttribArray(aLoc.p); gl.enableVertexAttribArray(aLoc.n); gl.enableVertexAttribArray(aLoc.c);
    gl.vertexAttribPointer(aLoc.p, 3, gl.FLOAT, false, 36, 0); gl.vertexAttribPointer(aLoc.n, 3, gl.FLOAT, false, 36, 12); gl.vertexAttribPointer(aLoc.c, 3, gl.FLOAT, false, 36, 24);
  }
  // draw: model matrix, tint (linear? no: sRGB 0..1 multiplier), opts {mode, grain, alpha, spec}
  function draw(m, model, tint, o) {
    o = o || {};
    if (inShadow) { gl.uniformMatrix4fv(U.h.uModel, false, model || I3); bindMesh(m); gl.drawElements(gl.TRIANGLES, m.count, gl.UNSIGNED_INT, 0); return; }
    const u = U.m;
    gl.uniformMatrix4fv(u.uModel, false, model || I3);
    gl.uniformMatrix3fv(u.uNM, false, model ? M.normalMat(model) : NI);
    gl.uniform3fv(u.uTint, tint || [1, 1, 1]);
    gl.uniform1f(u.uMode, o.mode || 0); gl.uniform1f(u.uGrain, o.grain || 0); gl.uniform1f(u.uAlpha, o.alpha == null ? 1 : o.alpha); gl.uniform1f(u.uSpec, o.spec == null ? 0.15 : o.spec);
    bindMesh(m);
    gl.drawElements(gl.TRIANGLES, m.count, gl.UNSIGNED_INT, 0);
  }
  function blend(on) { if (on) { gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA); gl.depthMask(false); } else { gl.disable(gl.BLEND); gl.depthMask(true); } }
  function drawPoints(data, n, vp, scale, col) {
    if (!n) return;
    gl.useProgram(progPts); gl.uniformMatrix4fv(U.p.uVP, false, vp); gl.uniform1f(U.p.uScale, scale); gl.uniform3fv(U.p.uCol, col);
    gl.bindBuffer(gl.ARRAY_BUFFER, ptBuf); gl.bufferData(gl.ARRAY_BUFFER, data.subarray(0, n * 5), gl.DYNAMIC_DRAW);
    const a = gl.getAttribLocation(progPts, 'aPos'), b = gl.getAttribLocation(progPts, 'aSA');
    gl.enableVertexAttribArray(a); gl.enableVertexAttribArray(b);
    gl.vertexAttribPointer(a, 3, gl.FLOAT, false, 20, 0); gl.vertexAttribPointer(b, 2, gl.FLOAT, false, 20, 12);
    gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA); gl.depthMask(false);
    gl.drawArrays(gl.POINTS, 0, n);
    gl.depthMask(true); gl.disable(gl.BLEND); gl.disableVertexAttribArray(a); gl.disableVertexAttribArray(b);
    gl.useProgram(progMain);
  }

  const G = {};
  window.GFX = { M, Geo, SH, G, env, init, resize, upload, mesh, free, begin, drawSky, draw, blend, drawPoints, endFrame, drawDynamic, shadowBegin, shadowEnd, lin, rgb, setTime(t) { time = t; }, size() { return [W, H]; } };
})();
