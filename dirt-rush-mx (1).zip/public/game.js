/* Dirt Rush MX - game logic: physics, AI, race flow, HUD, menu (3D drawing lives in render3d.js) */
(function () {
  'use strict';
  const LIST = window.TRACKS.list;
  const $ = id => document.getElementById(id);
  const glc = $('game'), hud = $('hud'), hctx = hud.getContext('2d');
  let W = 0, H = 0, DPR = 1, glOK = true;
  function resize() {
    DPR = Math.min(2, window.devicePixelRatio || 1);
    W = innerWidth; H = innerHeight;
    hud.width = W * DPR; hud.height = H * DPR; hud.style.width = W + 'px'; hud.style.height = H + 'px';
    if (window.R3 && glOK) window.R3.resize(W, H, Math.min(DPR, 1.5));
  }

  const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
  function shade(hex, f) {
    const m = /^#([0-9a-f]{6})$/i.exec(hex); if (!m) return hex;
    const n = parseInt(m[1], 16); let r = n >> 16, g = (n >> 8) & 255, b = n & 255;
    if (f < 0) { r *= 1 + f; g *= 1 + f; b *= 1 + f; } else { r += (255 - r) * f; g += (255 - g) * f; b += (255 - b) * f; }
    return 'rgb(' + (r | 0) + ',' + (g | 0) + ',' + (b | 0) + ')';
  }
  function fmt(t) {
    if (t == null || !isFinite(t)) return '--:--.--';
    const m = Math.floor(t / 60), s = t - m * 60;
    return (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s.toFixed(2);
  }

  /* ---------------- settings ---------------- */
  const store = {
    get(k, d) { try { const v = localStorage.getItem('drmx.' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem('drmx.' + k, JSON.stringify(v)); } catch (e) { } }
  };
  const settings = Object.assign({ bike: 'mx450', rivals: 3, color: '#ff6a1a', muted: false }, store.get('settings', {}));
  const saveSettings = () => store.set('settings', settings);

  /* ---------------- bike classes ---------------- */
  const CLASSES = {
    mx450: { label: '450F', m: 190, I: 64, rx: -0.72, fx: 0.74, hy: -0.38, r: 0.33, P: 19000, F: 2100, cd: 0.62, k: 32000, c: 2300, mu: 1.5, lean: 420, sc: 1, top: 31 },
    mx250: { label: '250F', m: 178, I: 58, rx: -0.72, fx: 0.74, hy: -0.38, r: 0.33, P: 14500, F: 1800, cd: 0.62, k: 30000, c: 2200, mu: 1.5, lean: 400, sc: 1, top: 28 },
    pit: { label: 'Pit 125', m: 118, I: 30, rx: -0.52, fx: 0.56, hy: -0.28, r: 0.25, P: 3800, F: 900, cd: 0.5, k: 20000, c: 1500, mu: 1.5, lean: 230, sc: 0.78, top: 19.5 }
  };
  Object.keys(CLASSES).forEach(k => { CLASSES[k].wb = CLASSES[k].fx - CLASSES[k].rx; });

  /* ---------------- audio ---------------- */
  let actx = null, osc1, osc2, gainN, filt, noiseG;
  function initAudio() {
    if (actx) return;
    try {
      actx = new (window.AudioContext || window.webkitAudioContext)();
      osc1 = actx.createOscillator(); osc1.type = 'sawtooth';
      osc2 = actx.createOscillator(); osc2.type = 'square';
      filt = actx.createBiquadFilter(); filt.type = 'lowpass'; filt.frequency.value = 900; filt.Q.value = 2;
      gainN = actx.createGain(); gainN.gain.value = 0;
      const g2 = actx.createGain(); g2.gain.value = 0.5;
      osc1.connect(filt); osc2.connect(g2); g2.connect(filt); filt.connect(gainN); gainN.connect(actx.destination);
      osc1.start(); osc2.start();
      // wind / dirt noise
      const buf = actx.createBuffer(1, actx.sampleRate * 2, actx.sampleRate), d = buf.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
      const ns = actx.createBufferSource(); ns.buffer = buf; ns.loop = true;
      const nf = actx.createBiquadFilter(); nf.type = 'bandpass'; nf.frequency.value = 700; nf.Q.value = 0.6;
      noiseG = actx.createGain(); noiseG.gain.value = 0; ns.connect(nf); nf.connect(noiseG); noiseG.connect(actx.destination); ns.start();
    } catch (e) { actx = null; }
  }
  function engineSound(rpm, thr, on, speed) {
    if (!actx) return;
    const t = actx.currentTime;
    osc1.frequency.setTargetAtTime(34 + rpm * 115, t, 0.05); osc2.frequency.setTargetAtTime(17 + rpm * 58, t, 0.05);
    filt.frequency.setTargetAtTime(400 + rpm * 1500 + thr * 700, t, 0.05);
    gainN.gain.setTargetAtTime(on && !settings.muted ? 0.035 + thr * 0.05 : 0, t, 0.08);
    noiseG.gain.setTargetAtTime(on && !settings.muted ? clamp(speed / 40, 0, 1) * 0.05 : 0, t, 0.1);
  }

  /* ---------------- input ---------------- */
  const keys = {}, touch = { thr: 0, brk: 0, sl: 0, sr: 0, lb: 0, lf: 0 };
  addEventListener('keydown', e => {
    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code)) e.preventDefault();
    if (e.repeat) return;
    keys[e.code] = true; initAudio(); onKey(e.code);
  });
  addEventListener('keyup', e => { keys[e.code] = false; });
  addEventListener('blur', () => { for (const k in keys) keys[k] = false; });
  function input() {
    const k = keys;
    let thr = (k.ArrowUp || k.KeyW || touch.thr) ? 1 : 0, brk = (k.ArrowDown || k.KeyS || touch.brk) ? 1 : 0;
    let steer = ((k.ArrowLeft || k.KeyA || touch.sl) ? 1 : 0) - ((k.ArrowRight || k.KeyD || touch.sr) ? 1 : 0);
    let lean = ((k.KeyE || k.Space || touch.lb) ? 1 : 0) - ((k.KeyQ || k.ShiftLeft || k.ShiftRight || touch.lf) ? 1 : 0);
    try {
      const gp = (navigator.getGamepads && navigator.getGamepads()[0]);
      if (gp) {
        const dz = v => Math.abs(v) < 0.12 ? 0 : v;
        if (gp.buttons[7] && gp.buttons[7].value > 0.05) thr = Math.max(thr, gp.buttons[7].value);
        if (gp.buttons[6] && gp.buttons[6].value > 0.05) brk = Math.max(brk, gp.buttons[6].value);
        if (dz(gp.axes[0])) steer = -dz(gp.axes[0]);
        if (dz(gp.axes[3])) lean = dz(gp.axes[3]);
      }
    } catch (e) { }
    return { thr, brk, steer, lean };
  }
  document.querySelectorAll('#touch button').forEach(btn => {
    const k = btn.dataset.k;
    const on = e => { e.preventDefault(); touch[k] = 1; initAudio(); btn.classList.add('on'); };
    const off = e => { e.preventDefault(); touch[k] = 0; btn.classList.remove('on'); };
    btn.addEventListener('pointerdown', on); btn.addEventListener('pointerup', off);
    btn.addEventListener('pointercancel', off); btn.addEventListener('pointerleave', off);
  });

  /* ---------------- physics ---------------- */
  const PH = 1 / 180;

  function contact(T, hx, hy, r) {
    let best = 0, nx = 0, ny = 1;
    const N = 17;
    for (let i = 0; i < N; i++) {
      const dx = (i / (N - 1) * 2 - 1) * r * 0.99;
      const gx = hx + dx, gy = T.h(gx);
      const ddx = hx - gx, ddy = hy - gy, d2 = ddx * ddx + ddy * ddy;
      if (hy < gy) {
        const pen = r + (gy - hy);
        if (pen > best) { best = pen; nx = 0; ny = 1; }
      } else if (d2 < r * r) {
        const d = Math.sqrt(d2) || 1e-6, pen = r - d;
        if (pen > best) { best = pen; nx = ddx / d; ny = ddy / d; }
      }
    }
    return { pen: best, nx, ny };
  }

  class Bike {
    constructor(T, C, color, name, player, skill) {
      this.T = T; this.C = C; this.color = color; this.name = name; this.player = player; this.skill = skill;
      this.cp = 0; this.finished = false; this.finishT = null; this.crashes = 0;
      this.wr = 0; this.pose = 0; this.thr = 0; this.lane = 0; this.phase = Math.random() * 6;
      this.d = 0; this.dv = 0; this.yawOff = 0; this.roll = 0; this.steerVis = 0; this.landed = 0;
    }
    reset(x, speed, d) {
      const T = this.T, sl = Math.atan2(T.h(x + 0.5) - T.h(x - 0.5), 1);
      this.x = x; this.y = T.h(x) + 0.68; this.a = sl;
      this.vx = speed * Math.cos(sl); this.vy = speed * Math.sin(sl); this.w = 0;
      this.dead = false; this.deadT = 0; this.rag = null; this.stuckT = 0; this.thr = 0;
      this.grounded = 0; this.rPen = 0; this.fPen = 0;
      this.d = d || 0; this.dv = 0; this.yawOff = 0; this.roll = 0;
    }
    step(dt, inp) {
      const T = this.T, C = this.C, co = Math.cos(this.a), si = Math.sin(this.a);
      let fx = 0, fy = -C.m * 9.81, tq = 0, grounded = 0;
      const live = !this.dead;
      this.thr += (inp.thr - this.thr) * Math.min(1, dt * 9);
      for (let i = 0; i < 2; i++) {
        const lx = i === 0 ? C.rx : C.fx;
        const hx = this.x + lx * co - C.hy * si, hy = this.y + lx * si + C.hy * co;
        const c = contact(T, hx, hy, C.r);
        if (i === 0) this.rPen = c.pen; else this.fPen = c.pen;
        if (c.pen <= 0) continue;
        grounded |= (1 << i);
        const rx = hx - this.x, ry = hy - this.y;
        const vhx = this.vx - this.w * ry, vhy = this.vy + this.w * rx;
        const vn = vhx * c.nx + vhy * c.ny;
        let Fn = C.k * c.pen - (vn < 0 ? C.c : C.c * 0.45) * vn;
        if (c.pen > 0.22) Fn += C.k * 4 * (c.pen - 0.22);
        Fn = clamp(Fn, 0, 60000);
        let Fx = c.nx * Fn, Fy = c.ny * Fn;
        const tx = c.ny, ty = -c.nx, vt = vhx * tx + vhy * ty;
        let Ft = -clamp(vt * 60, -0.03 * Fn, 0.03 * Fn);
        if (live) {
          if (i === 0) {
            const up = clamp((c.ny - 0.25) / 0.45, 0, 1);
            const Fd = Math.min(C.F, C.P / Math.max(vt, 3.5)) * this.thr * up;
            Ft += Math.min(Fd, C.mu * Fn);
          }
          if (inp.brk) { const bm = C.mu * Fn * (i === 0 ? 0.5 : 0.8) * Math.min(1, inp.brk); Ft -= clamp(vt * 400, -bm, bm); }
        }
        Fx += tx * Ft; Fy += ty * Ft;
        fx += Fx; fy += Fy; tq += rx * Fy - ry * Fx;
        if (i === 0) this.rVt = vt;
        if (vn < -3.5 && this.landed <= 0) this.landed = Math.min(1, -vn / 9);   // landing impact for camera shake
      }
      const v = Math.hypot(this.vx, this.vy);
      fx -= C.cd * v * this.vx; fy -= C.cd * v * this.vy;
      const air = !grounded;
      if (live) {
        tq += inp.lean * C.lean * (air ? 1 : 0.7);
        if (air) tq += (this.thr * 0.3 - inp.brk * 0.5) * C.lean * 0.3;
        if (!air) {
          const sl = Math.atan2(T.h(this.x + 0.7) - T.h(this.x - 0.7), 1.4);
          tq += (sl - this.a) * C.lean * 0.9 * (1 - 0.7 * Math.abs(inp.lean));
        }
      }
      // cornering drag when carving hard
      if (grounded && live) fx -= Math.abs(this.dv) * Math.abs(inp.steer) * 5 * (C.m / 190);
      this.vx += fx / C.m * dt; this.vy += fy / C.m * dt; this.w += tq / C.I * dt;
      this.w *= Math.exp(-(air ? 1.5 : 2.6) * dt);
      this.x += this.vx * dt; this.y += this.vy * dt; this.a += this.w * dt;
      if (this.a > Math.PI) this.a -= 2 * Math.PI; else if (this.a < -Math.PI) this.a += 2 * Math.PI;
      this.grounded = grounded;
      this.wr += (air ? this.thr * 25 : (this.rVt || 0) / C.r) * dt;
      this.pose += ((live ? inp.lean : 0) - this.pose) * Math.min(1, dt * 7);
      if (this.landed > 0) this.landed = Math.max(0, this.landed - dt * 0.0001);   // cleared by renderer

      /* lateral (steering) model */
      const vf = Math.max(this.vx, 0), k = T.curv(this.x);
      const Vs = Math.min(8, 4.2 + vf * 0.14);
      const aOut = -vf * vf * k * 0.42;
      if (grounded) this.dv += (((live ? inp.steer : 0) * Vs - this.dv) * 3.2 + aOut) * dt;
      else this.dv *= Math.exp(-0.15 * dt);
      this.d += this.dv * dt;
      const lim = T.half + 0.3;
      if (Math.abs(this.d) > T.half - 0.3 && grounded) { this.vx *= Math.exp(-0.8 * dt); this.dv *= Math.exp(-1.5 * dt); }
      if (Math.abs(this.d) > lim) { this.d = this.d > 0 ? lim : -lim; if (this.d * this.dv > 0) this.dv = 0; }
      const tgtYaw = Math.atan2(this.dv, Math.max(vf, 4));
      this.yawOff += (tgtYaw - this.yawOff) * Math.min(1, dt * 8);
      const tgtRoll = clamp(Math.atan2(vf * vf * k * 0.4, 9.81) + (live ? inp.steer : 0) * 0.28 * Math.min(1, vf / 8), -0.8, 0.8);
      this.roll += ((grounded ? tgtRoll : tgtRoll * 0.3) - this.roll) * Math.min(1, dt * 6);
      this.steerVis += (((live ? inp.steer : 0) * 0.38) - this.steerVis) * Math.min(1, dt * 10);
    }
  }

  function riderPose(b) {         // local (bike frame), x forward y up; used for head crash test and by the renderer
    const C = b.C;
    const hip = [C.rx + 0.30 * C.wb, C.hy + 0.68 * C.sc];
    const th = 0.55 - 0.5 * b.pose, s = Math.sin(th), c = Math.cos(th);
    const sh = [hip[0] + s * 0.56, hip[1] + c * 0.56];
    const head = [sh[0] + s * 0.24, sh[1] + c * 0.24];
    return { hip, sh, head, th };
  }
  function toWorld(b, p) {
    const co = Math.cos(b.a), si = Math.sin(b.a);
    return [b.x + p[0] * co - p[1] * si, b.y + p[0] * si + p[1] * co];
  }

  /* ---------------- race ---------------- */
  let G = null;
  const AINAMES = ['Rook', 'Vega', 'Dash'], AICOLS = ['#2f7bff', '#22c55e', '#e5e7eb'], AISKILL = [0.9, 0.95, 0.99], AILANE = [-2.0, 2.0, 0.2];

  function makeRace(ti, o) {
    const T = LIST[ti];
    const clsKey = T.cat === 'pit' ? 'pit' : o.bike;
    const riders = [];
    const mk = (name, color, player, skill, i, lane) => {
      const b = new Bike(T, CLASSES[clsKey], color, name, player, skill);
      b.lane = clamp(lane, -(T.half - 1.4), T.half - 1.4);
      b.reset(T.startX - (i % 2) * 1.2, 0, player ? 0 : b.lane); return b;
    };
    riders.push(mk('You', o.color, true, 1, 0, 0));
    for (let i = 0; i < o.rivals; i++) riders.push(mk(AINAMES[i], AICOLS[i], false, AISKILL[i], i + 1, AILANE[i]));
    return { T, ti, riders, player: riders[0], t: 0, acc: 0, state: 'countdown', cd: 3.4, endT: 0, clsKey, respawns: 0, parts: [], shake: 0, flash: 0 };
  }

  function headWorldS(b) { const p = riderPose(b); return toWorld(b, p.head); }

  function crash(b) {
    b.dead = true; b.deadT = 0; b.crashes++;
    const hp = headWorldS(b);
    b.rag = {
      s: hp[0], y: hp[1], d: b.d, vs: b.vx * 0.9 + (Math.random() - 0.3) * 2, vy: b.vy * 0.7 + 2 + Math.random() * 2, vd: b.dv * 0.8 + (Math.random() - 0.5) * 3,
      ax: 0, ay: 0, az: 0, wx: (Math.random() - 0.5) * 9, wy: (Math.random() - 0.5) * 5, wz: -(3 + Math.random() * 9)
    };
    (window.__crashLog = window.__crashLog || []).push({ x: +b.x.toFixed(1), vx: +b.vx.toFixed(1), a: +b.a.toFixed(2) });
    if (b.player && G) G.shake = 0.45;
  }
  function respawn(b) {
    const T = G.T;
    if (!b.player) {                                   // AI rescue: skip ahead if it keeps failing the same spot
      if (b.lastCp === b.cp) b.retry = (b.retry || 0) + 1; else b.retry = 0;
      b.lastCp = b.cp;
      if (b.retry >= 2 && b.cp + 1 < T.cps.length) { b.cp++; b.retry = 0; b.lastCp = b.cp; }
    }
    b.reset(T.cps[b.cp], 12, b.player ? 0 : b.lane);
    if (b.player) G.respawns++;
  }

  function aiInput(b) {
    const T = G.T, C = b.C, air = !b.grounded, sp = b.vx;
    let thr = sp < C.top * b.skill ? 1 : 0.4, brk = 0;
    const kk = T.curv(b.x + 3);
    // slow for tight corners
    const vcorner = Math.sqrt(Math.max(1, 6.5 / Math.max(Math.abs(kk) * 0.42, 1e-4)));
    if (b.grounded && Math.abs(kk) > 0.012 && sp > vcorner * b.skill) { thr = 0.3; brk = 0.3; }
    const look = air ? clamp(sp * 0.55, 4, 16) : 1.0;
    const gx = b.x + look;
    const slope = Math.atan2(T.h(gx + 0.6) - T.h(gx - 0.6), 1.2);
    const lean = clamp((slope - b.a) * 4.5 - b.w * 1.1, -1, 1);
    if (air) thr = 0.2;
    if (b.finished) { thr = 0; brk = 0.5; }
    const v = Math.max(sp, 0), Vs = Math.min(8, 4.2 + v * 0.14);
    const ff = (v * v * kk * 0.42) / (3.2 * Vs);
    const lane = b.lane + Math.sin(b.x * 0.013 + b.phase) * 1.0;
    const steer = clamp(ff + (lane - b.d) * 0.35 - b.dv * 0.18, -1, 1);
    return { thr, brk, lean, steer };
  }

  function post(b, dt) {
    const T = G.T;
    if (!b.dead && !b.finished) {
      const hp = headWorldS(b);
      if (hp[1] - 0.12 < T.h(hp[0])) crash(b);
    }
    while (b.cp + 1 < T.cps.length && b.x > T.cps[b.cp + 1]) b.cp++;
    if (!b.finished && b.x >= T.finishX) { b.finished = true; b.finishT = G.t; }
    if (b.dead) {
      b.deadT += dt;
      const r = b.rag;
      if (r) {
        r.vy -= 9.81 * dt; r.s += r.vs * dt; r.y += r.vy * dt; r.d += r.vd * dt;
        r.ax += r.wx * dt; r.ay += r.wy * dt; r.az += r.wz * dt;
        const g = T.h(r.s) + 0.22;
        if (r.y < g) { r.y = g; r.vy = Math.abs(r.vy) * 0.25; r.vs *= 0.93; r.vd *= 0.9; r.wx *= 0.9; r.wy *= 0.9; r.wz *= 0.9; }
      }
      if (b.deadT > 1.5) respawn(b);
    } else if (G.state === 'racing' && !b.finished) {
      if (Math.abs(b.vx) < 0.6) b.stuckT += dt; else b.stuckT = 0;
      if (b.stuckT > (b.player ? 1e9 : 2.5)) respawn(b);
    }
    // dust / roost from the rear tyre
    if (!b.dead && (b.grounded & 1) && b.thr > 0.3 && b.vx > 2 && Math.random() < 0.5 && Math.abs(b.x - G.player.x) < 45) {
      const co = Math.cos(b.a), si = Math.sin(b.a), C = b.C;
      const hx = b.x + C.rx * co - C.hy * si, hy = b.y + C.rx * si + C.hy * co;
      G.parts.push({ s: hx, y: hy - C.r + b.rPen, d: b.d + (Math.random() - 0.5) * 0.3, vs: -b.vx * 0.25 - Math.random() * 2, vy: 1.2 + Math.random() * 2.2, vd: (Math.random() - 0.5) * 2.2, life: 1.1, max: 1.1, size: 0.5 + Math.random() * 0.5 });
    }
    if (!b.dead && b.landed > 0) {      // landing puff
      const C = b.C;
      for (let q = 0; q < 4; q++) G.parts.push({ s: b.x + (Math.random() - 0.5), y: T.h(b.x) + 0.1, d: b.d + (Math.random() - 0.5) * 0.6, vs: (Math.random() - 0.5) * 3, vy: 0.5 + Math.random() * 1.5, vd: (Math.random() - 0.5) * 3, life: 1.0, max: 1.0, size: 0.7 + Math.random() * 0.6 });
      if (b.player) G.shake = Math.max(G.shake, b.landed * 0.5);
      b.landed = 0;
    }
  }

  function stepAll(dt, pin) {
    const racing = G.state === 'racing';
    for (const b of G.riders) {
      let inp;
      if (!racing) inp = { thr: 0, brk: 1, lean: 0, steer: 0 };
      else if (b.player) inp = b.finished ? { thr: 0, brk: 0.6, lean: 0, steer: 0 } : pin;
      else inp = aiInput(b);
      b.step(dt, inp);
      post(b, dt);
    }
    if (racing && !G.player.finished) G.t += dt;
    else if (racing) G.endT += dt;
    for (let i = G.parts.length - 1; i >= 0; i--) {
      const p = G.parts[i]; p.life -= dt; p.s += p.vs * dt; p.y += p.vy * dt; p.d += p.vd * dt; p.vy -= 1.0 * dt; p.vs *= Math.exp(-1.2 * dt); p.size += dt * 0.9;
      if (p.life <= 0) G.parts.splice(i, 1);
    }
    if (G.parts.length > 380) G.parts.splice(0, G.parts.length - 380);
  }

  function ranking() {
    return G.riders.slice().sort((a, b) => {
      if (a.finished && b.finished) return a.finishT - b.finishT;
      if (a.finished) return -1; if (b.finished) return 1;
      return b.x - a.x;
    });
  }

  /* ---------------- headless simulation (testing) ---------------- */
  window.__sim = function (ti, bike, skill, maxT) {
    const saveG = G;
    G = makeRace(ti, { bike, color: '#fff', rivals: 0 });
    const b = G.riders[0]; b.player = false; b.skill = skill || 1; b.lane = 0; G.state = 'racing';
    let maxD = 0, edge = 0;
    while (G.t < (maxT || 300) && !b.finished) {
      stepAll(PH, null);
      if (!isFinite(b.x) || !isFinite(b.y)) break;
      maxD = Math.max(maxD, Math.abs(b.d)); if (Math.abs(b.d) > G.T.half - 0.3) edge++;
    }
    const r = { track: G.T.id, finished: b.finished, t: +(b.finishT || G.t).toFixed(1), crashes: b.crashes, x: Math.round(b.x), len: G.T.len, nan: !isFinite(b.x), maxD: +maxD.toFixed(1), half: G.T.half, edgeFrac: +(edge * PH / G.t).toFixed(2) };
    G = saveG; return r;
  };

  /* ---------------- HUD ---------------- */
  function roundRect(c, x, y, w, h, r) {
    c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath();
  }
  function catLabel(c) { return { sx: 'Supercross', mx: 'Motocross', pit: 'Pit Bike', cmp: 'Compound' }[c]; }
  function drawProfilePath(px, py, pw, ph, T, col, c) {
    const c2 = c || hctx, n = 120, span = Math.max(10, T.maxH - T.minH), total = T.finishX;
    c2.strokeStyle = col; c2.lineWidth = 2; c2.beginPath();
    for (let i = 0; i <= n; i++) {
      const x = (i / n) * total, y = py + ph - ((T.h(x) - T.minH) / span) * ph * 0.8 - 2;
      i ? c2.lineTo(px + (i / n) * pw, y) : c2.moveTo(px, y);
    }
    c2.stroke();
  }
  function drawMiniMap(x, y, w, h) {
    const T = G.T;
    if (!G.map) {
      let x0 = 1e9, x1 = -1e9, z0 = 1e9, z1 = -1e9;
      for (let i = 0; i < T.pathX.length; i += 8) { x0 = Math.min(x0, T.pathX[i]); x1 = Math.max(x1, T.pathX[i]); z0 = Math.min(z0, T.pathZ[i]); z1 = Math.max(z1, T.pathZ[i]); }
      G.map = { x0, x1, z0, z1 };
    }
    const m = G.map, sc = Math.min((w - 16) / Math.max(1, m.x1 - m.x0), (h - 16) / Math.max(1, m.z1 - m.z0));
    const ox = x + (w - (m.x1 - m.x0) * sc) / 2, oy = y + (h - (m.z1 - m.z0) * sc) / 2;
    const P = (px, pz) => [ox + (px - m.x0) * sc, oy + (pz - m.z0) * sc];
    hctx.fillStyle = 'rgba(10,12,18,.55)'; roundRect(hctx, x, y, w, h, 10); hctx.fill();
    hctx.strokeStyle = 'rgba(255,255,255,.55)'; hctx.lineWidth = 3; hctx.lineJoin = 'round'; hctx.beginPath();
    for (let i = 0; i < T.pathX.length; i += 8) { const p = P(T.pathX[i], T.pathZ[i]); i ? hctx.lineTo(p[0], p[1]) : hctx.moveTo(p[0], p[1]); }
    hctx.stroke();
    G.riders.slice().reverse().forEach(b => {
      const ps = T.pos(clamp(b.x, 0, T.finishX)), p = P(ps.x, ps.z);
      hctx.fillStyle = b.color; hctx.strokeStyle = '#000'; hctx.lineWidth = 1.5; hctx.beginPath(); hctx.arc(p[0], p[1], b.player ? 5 : 4, 0, 7); hctx.fill(); hctx.stroke();
    });
  }
  const CAMS = ['Chase', 'Far', 'Helmet'];
  let camMode = 0;
  function drawHUD() {
    const c = hctx;
    c.setTransform(DPR, 0, 0, DPR, 0, 0); c.clearRect(0, 0, W, H);
    if (!G) return;
    const T = G.T, P = G.player;
    c.textAlign = 'left';
    const kmh = Math.round(Math.hypot(P.vx, P.vy) * 3.6);
    c.fillStyle = 'rgba(10,12,18,.62)'; roundRect(c, 16, 16, 210, 86, 14); c.fill();
    c.fillStyle = '#fff'; c.font = '800 44px system-ui,sans-serif'; c.fillText(kmh, 30, 66);
    c.font = '700 13px system-ui,sans-serif'; c.fillStyle = '#9aa3b2'; c.fillText('KM/H', 126, 66);
    c.fillStyle = 'rgba(255,255,255,.12)'; c.fillRect(30, 78, 180, 8);
    c.fillStyle = (P.rpm || 0) > 0.92 ? '#ff4d3d' : T.theme.accent; c.fillRect(30, 78, 180 * clamp(P.rpm || 0, 0, 1), 8);
    c.textAlign = 'right'; c.fillStyle = '#fff'; c.font = '800 26px system-ui,sans-serif'; c.fillText(String((P.gear || 0) + 1), 212, 58); c.font = '700 10px system-ui,sans-serif'; c.fillStyle = '#9aa3b2'; c.fillText('GEAR', 212, 30); c.textAlign = 'left';
    c.fillStyle = 'rgba(10,12,18,.62)'; roundRect(c, W - 236, 16, 220, 86, 14); c.fill();
    c.textAlign = 'right'; c.fillStyle = '#fff'; c.font = '800 30px ui-monospace,Menlo,monospace'; c.fillText(fmt(G.t), W - 30, 56);
    const rk = ranking(), pos = rk.indexOf(P) + 1;
    c.font = '700 15px system-ui,sans-serif'; c.fillStyle = '#ffb27a';
    c.fillText((G.riders.length > 1 ? 'P' + pos + ' / ' + G.riders.length + '  ·  ' : '') + 'Best ' + fmt(bestTime(G.ti, G.clsKey)), W - 30, 86);
    c.textAlign = 'center'; c.fillStyle = 'rgba(255,255,255,.9)'; c.font = '700 14px system-ui,sans-serif';
    c.fillText(T.name.toUpperCase() + '  ·  ' + catLabel(T.cat) + '  ·  ' + CAMS[camMode] + ' cam (C)', W / 2, 30);
    // elevation profile
    const pw = Math.min(560, W * 0.55), px = (W - pw) / 2, py = H - 56, ph = 36;
    c.fillStyle = 'rgba(10,12,18,.55)'; roundRect(c, px - 8, py - 10, pw + 16, ph + 20, 10); c.fill();
    drawProfilePath(px, py, pw, ph, T, 'rgba(255,255,255,.55)');
    const total = T.finishX;
    G.riders.slice().reverse().forEach(b => {
      const x = px + clamp(b.x / total, 0, 1) * pw, y = py + ph - ((T.h(clamp(b.x, 0, total)) - T.minH) / Math.max(10, T.maxH - T.minH)) * ph * 0.8 - 2;
      c.fillStyle = b.color; c.strokeStyle = '#000'; c.lineWidth = 1.5; c.beginPath(); c.arc(x, y - 4, b.player ? 6 : 4.5, 0, 7); c.fill(); c.stroke();
    });
    if (W > 700) drawMiniMap(16, 114, 170, 130);
    if (G.state === 'countdown') {
      const n = Math.ceil(G.cd - 0.4);
      c.fillStyle = '#fff'; c.font = '900 110px system-ui,sans-serif'; c.textAlign = 'center';
      c.shadowColor = 'rgba(0,0,0,.5)'; c.shadowBlur = 20;
      c.fillText(n > 0 ? n : 'SET', W / 2, H * 0.3); c.shadowBlur = 0;
      c.font = '700 16px system-ui,sans-serif'; c.fillStyle = '#ffd2b0'; c.fillText('Hold the throttle and get ready', W / 2, H * 0.3 + 34);
    } else if (G.state === 'racing' && G.t < 1.1) {
      c.fillStyle = T.theme.accent; c.font = '900 96px system-ui,sans-serif'; c.textAlign = 'center'; c.globalAlpha = 1 - G.t / 1.1;
      c.fillText('GO!', W / 2, H * 0.3); c.globalAlpha = 1;
    }
    if (P.dead) { c.fillStyle = '#ff5a4d'; c.font = '900 40px system-ui,sans-serif'; c.textAlign = 'center'; c.fillText('WIPEOUT', W / 2, H * 0.3); }
    if (P.finished && G.state === 'racing') { c.fillStyle = '#fff'; c.font = '900 56px system-ui,sans-serif'; c.textAlign = 'center'; c.fillText('FINISH!', W / 2, H * 0.3); }
    if (Math.abs(P.d) > T.half - 0.5 && !P.dead) { c.fillStyle = '#ffcf5a'; c.font = '800 16px system-ui,sans-serif'; c.textAlign = 'center'; c.fillText('Edge of the track', W / 2, H * 0.4); }
  }

  /* ---------------- flow / loop ---------------- */
  let last = performance.now(), paused = false, inRace = false, wallT = 0;
  function frame(now) {
    const dt = Math.min(0.05, (now - last) / 1000); last = now; wallT += dt;
    if (G && inRace && !paused) {
      if (G.state === 'countdown') { G.cd -= dt; if (G.cd <= 0) { G.state = 'racing'; } }
      G.acc += dt;
      const pin = input();
      let n = 0;
      while (G.acc >= PH && n++ < 12) { G.acc -= PH; stepAll(PH, pin); }
      if (n >= 12) G.acc = 0;
      const P = G.player;
      const spd = Math.max(0, P.vx), top = P.C.top, gearMax = [0.2, 0.36, 0.53, 0.74, 1.0].map(f => f * top * 1.02);
      let gi = 0; while (gi < 4 && spd > gearMax[gi] * 0.93) gi++;
      if (gi !== P.gear) { P.shiftT = 0.14; P.gear = gi; }
      P.shiftT = Math.max(0, (P.shiftT || 0) - dt);
      const lo = gi ? gearMax[gi - 1] * 0.62 : 0;
      let rpm = 0.22 + 0.78 * clamp((spd - lo) / (gearMax[gi] - lo), 0, 1);
      if (spd < 1.5 && !P.thr) rpm = 0.2 + (pin.thr ? 0.55 : 0);
      if (P.shiftT > 0) rpm *= 0.72;
      if (!P.grounded && P.thr > 0.3) rpm = Math.min(1.1, rpm + 0.25);
      P.rpm = rpm;
      engineSound(rpm * 1.1, pin.thr || P.thr, true, Math.hypot(P.vx, P.vy));
      if (G.state === 'racing' && P.finished) {
        if (G.riders.every(b => b.finished) || G.endT > 7) showResults();
      }
    } else engineSound(0, 0, false, 0);
    if (G && glOK && window.R3) { try { window.R3.render(G, dt, camMode, wallT, paused); } catch (e) { console.error(e); glOK = false; $('glerr').classList.remove('hide'); } }
    drawHUD();
    requestAnimationFrame(frame);
  }

  function bestKey(ti, cls) { return 'best.' + LIST[ti].id + '.' + cls; }
  function bestTime(ti, cls) { return store.get(bestKey(ti, cls), null); }

  function startRace(ti) {
    initAudio();
    G = makeRace(ti, settings);
    inRace = true; paused = false;
    try { if (window.R3 && glOK) window.R3.setTrack(G); } catch (e) { console.error(e); glOK = false; $('glerr').classList.remove('hide'); }
    $('menu').classList.add('hide'); $('results').classList.add('hide'); $('pause').classList.add('hide');
    $('touch').classList.toggle('show', matchMedia('(pointer:coarse)').matches);
  }
  function toMenu() {
    inRace = false; G = null; paused = false;
    if (window.R3 && glOK) window.R3.clear();
    $('menu').classList.remove('hide'); $('results').classList.add('hide'); $('pause').classList.add('hide'); $('touch').classList.remove('show');
  }
  function showResults() {
    if (!inRace) return; inRace = false;
    const rk = ranking(), P = G.player, pos = rk.indexOf(P) + 1;
    const prev = bestTime(G.ti, G.clsKey); let nb = false;
    if (P.finishT != null && (prev == null || P.finishT < prev)) { store.set(bestKey(G.ti, G.clsKey), P.finishT); nb = true; }
    $('resTitle').textContent = G.riders.length > 1 ? (pos === 1 ? 'Victory!' : 'P' + pos + ' finish') : 'Run complete';
    $('resSub').textContent = G.T.name + ' · ' + catLabel(G.T.cat) + (nb ? ' · NEW BEST!' : '');
    let html = '';
    rk.forEach((b, i) => { html += '<div class="row' + (b.player ? ' me' : '') + '"><span>' + (i + 1) + '</span><i style="background:' + b.color + '"></i><b>' + b.name + '</b><em>' + (b.finished ? fmt(b.finishT) : 'DNF') + '</em></div>'; });
    html += '<div class="meta">Wipeouts: ' + P.crashes + '</div>';
    $('resTable').innerHTML = html;
    $('btnNext').style.display = G.ti < LIST.length - 1 ? '' : 'none';
    $('results').classList.remove('hide');
    buildGrid();
  }
  function onKey(code) {
    if (code === 'KeyC' && G) { camMode = (camMode + 1) % 3; return; }
    if (!inRace || !G) return;
    if (code === 'KeyR' && G.state === 'racing' && !G.player.finished) { respawn(G.player); }
    else if (code === 'KeyM') { settings.muted = !settings.muted; saveSettings(); }
    else if (code === 'Escape' || code === 'KeyP') { paused = !paused; $('pause').classList.toggle('hide', !paused); }
    else if (code === 'Enter' && G.player.finished) showResults();
  }
  $('btnRetry').onclick = () => startRace(G.ti);
  $('btnNext').onclick = () => startRace(Math.min(LIST.length - 1, G.ti + 1));
  $('btnMenu').onclick = toMenu;
  $('btnResume').onclick = () => { paused = false; $('pause').classList.add('hide'); };
  $('btnRestart').onclick = () => startRace(G.ti);
  $('btnQuit').onclick = toMenu;

  /* ---------------- menu ---------------- */
  const CATS = [['sx', 'Supercross'], ['mx', 'Motocross'], ['pit', 'Pit Bike'], ['cmp', 'Compounds']];
  let tab = store.get('tab', 'sx');
  function buildTabs() {
    $('tabs').innerHTML = CATS.map(c => '<button data-c="' + c[0] + '" class="' + (c[0] === tab ? 'on' : '') + '">' + c[1] + ' <small>' + LIST.filter(t => t.cat === c[0]).length + '</small></button>').join('');
    $('tabs').querySelectorAll('button').forEach(b => b.onclick = () => { tab = b.dataset.c; store.set('tab', tab); buildTabs(); buildGrid(); });
  }
  function buildGrid() {
    const g = $('grid'); g.innerHTML = '';
    LIST.filter(t => t.cat === tab).forEach(T => {
      const clsKey = T.cat === 'pit' ? 'pit' : settings.bike, best = bestTime(T.n, clsKey);
      const card = document.createElement('button'); card.className = 'card';
      card.style.setProperty('--acc', T.theme.accent); card.style.setProperty('--dirt', T.theme.dirt);
      card.innerHTML = '<div class="top"><span class="num">' + String(T.n + 1).padStart(2, '0') + '</span><span class="stars">' + '★'.repeat(T.d) + '<u>' + '★'.repeat(5 - T.d) + '</u></span></div><h3>' + T.name + '</h3><canvas width="240" height="64"></canvas><div class="bot"><span>' + T.len + ' m</span><span>' + (best ? '⏱ ' + fmt(best) : 'No time yet') + '</span></div>';
      const c = card.querySelector('canvas').getContext('2d');
      c.fillStyle = shade(T.theme.dirt, -0.1); c.globalAlpha = 0.25; c.fillRect(0, 0, 240, 64); c.globalAlpha = 1;
      // top-down outline of the circuit
      let x0 = 1e9, x1 = -1e9, z0 = 1e9, z1 = -1e9;
      for (let i = 0; i < T.pathX.length; i += 8) { x0 = Math.min(x0, T.pathX[i]); x1 = Math.max(x1, T.pathX[i]); z0 = Math.min(z0, T.pathZ[i]); z1 = Math.max(z1, T.pathZ[i]); }
      const sc = Math.min(232 / Math.max(1, x1 - x0), 56 / Math.max(30, z1 - z0));
      c.strokeStyle = T.theme.accent; c.lineWidth = 2.5; c.lineJoin = 'round'; c.beginPath();
      for (let i = 0; i < T.pathX.length; i += 8) { const px = 4 + (T.pathX[i] - x0) * sc + (232 - (x1 - x0) * sc) / 2, pz = 32 + (T.pathZ[i] - (z0 + z1) / 2) * sc; i ? c.lineTo(px, pz) : c.moveTo(px, pz); }
      c.stroke();
      card.onclick = () => startRace(T.n);
      g.appendChild(card);
    });
  }
  function buildOpts() {
    const bikes = Object.keys(CLASSES);
    $('bikeSel').innerHTML = bikes.map(k => '<button data-k="' + k + '" class="' + (settings.bike === k ? 'on' : '') + '">' + CLASSES[k].label + '</button>').join('');
    $('bikeSel').querySelectorAll('button').forEach(b => b.onclick = () => { settings.bike = b.dataset.k; saveSettings(); buildOpts(); buildGrid(); });
    $('rivalSel').innerHTML = [0, 1, 2, 3].map(n => '<button data-n="' + n + '" class="' + (settings.rivals === n ? 'on' : '') + '">' + n + '</button>').join('');
    $('rivalSel').querySelectorAll('button').forEach(b => b.onclick = () => { settings.rivals = +b.dataset.n; saveSettings(); buildOpts(); });
    const cols = ['#ff6a1a', '#ef4444', '#facc15', '#a855f7', '#14b8a6', '#ec4899'];
    $('colSel').innerHTML = cols.map(c => '<button data-c="' + c + '" class="sw ' + (settings.color === c ? 'on' : '') + '" style="background:' + c + '"></button>').join('');
    $('colSel').querySelectorAll('button').forEach(b => b.onclick = () => { settings.color = b.dataset.c; saveSettings(); buildOpts(); });
  }

  /* ---------------- boot ---------------- */
  try {
    if (!window.GFX || !window.R3) throw new Error('renderer missing');
    window.GFX.init(glc);
  } catch (e) { console.error(e); glOK = false; $('glerr').classList.remove('hide'); }
  addEventListener('resize', resize); resize();
  buildTabs(); buildOpts(); buildGrid();
  requestAnimationFrame(frame);
  window.__game = { startRace, LIST, CLASSES, get G() { return G; }, setCam(m) { camMode = m; } };
})();
