/* Dirt Rush MX - 3D scene: terrain, scenery, bikes, riders, camera (uses gfx.js) */
(function () {
  'use strict';
  const GF = window.GFX, M = GF.M, SH = GF.SH, GS = GF.G;
  const DX = window.TRACKS.DX;
  const R3 = {};
  const PI = Math.PI;
  const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
  const smooth = t => { t = clamp(t, 0, 1); return t * t * (3 - 2 * t); };
  function mulberry(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
  const hash2 = (a, b) => { const n = Math.sin(a * 127.1 + b * 311.7) * 43758.5453; return n - Math.floor(n); };

  let T = null, world = null, W3, groundY;
  const cam = { px: 0, py: 3, pz: 0, th: 0, ty: 0, init: true, fov: 62 };
  let ptData = new Float32Array(400 * 5);
  const shapeCache = {};

  const SHP = { cyl14: SH.cyl(14, 1), cyl8: SH.cyl(8, 1), cone8: SH.cyl(8, 0), cone6: SH.cyl(6, 0), cone4: SH.cyl(4, 0), sph: SH.sph(8, 10) };
  const LAND = { sx: 0.4, mx: 3.2, pit: 1.2, cmp: 2.6 };
  const GROUND = { sx: '#2a2522', mx: '#4a7a36', pit: '#5b8c40', cmp: '#a98a55' };

  /* ---------- helpers for static geometry ---------- */
  const addBox = (g, x, y, z, sx, sy, sz, ry, col) => g.add(SH.box, M.chain(M.T(x, y, z), M.Ry(ry || 0), M.S(sx, sy, sz)), col);
  const addCyl = (g, x, y, z, d, h, col, shp) => g.add(shp || SHP.cyl8, M.chain(M.T(x, y + h / 2, z), M.S(d, h, d)), col);
  const addCone = (g, x, y, z, d, h, col, shp, ry) => g.add(shp || SHP.cone8, M.chain(M.T(x, y + h / 2, z), M.Ry(ry || 0), M.S(d, h, d)), col);
  const addSph = (g, x, y, z, sx, sy, sz, col) => g.add(SHP.sph, M.chain(M.T(x, y, z), M.S(sx, sy, sz)), col);
  function varyCol(hex, f) { const c = GF.rgb(hex); return 'rgb(' + clamp(c[0] * 255 * f | 0, 0, 255) + ',' + clamp(c[1] * 255 * f | 0, 0, 255) + ',' + clamp(c[2] * 255 * f | 0, 0, 255) + ')'; }

  /* ---------- world building ---------- */
  function buildTerrain() {
    const W = T.half, EXT = T.ext, sEnd = (T.arr.length - 1) * DX, step = 0.5;
    const offs = [0.5, 1.2, 2, 3, 4.5, 8, 14, EXT].map(v => W + v);
    const lat = [];
    for (let i = offs.length - 1; i >= 0; i--) lat.push(-offs[i]);
    lat.push(-W, -W * 0.75, -W * 0.5, -W * 0.25, 0, W * 0.25, W * 0.5, W * 0.75, W);
    for (let i = 0; i < offs.length; i++) lat.push(offs[i]);
    const nc = lat.length, nr = Math.floor(sEnd / step) + 1;
    const pos = new Float32Array(nr * nc * 3), col = new Float32Array(nr * nc * 3), nor = new Float32Array(nr * nc * 3);
    const dirt = GF.rgb(T.theme.dirt), gnd = GF.rgb(GROUND[T.cat]);
    const rnd = mulberry(T.n * 31 + 7);
    for (let i = 0; i < nr; i++) {
      const s = i * step, p = T.pos(s), lx = -Math.sin(p.th), lz = -Math.cos(p.th);
      const line = Math.sin(s * 0.011 + T.n) * 1.4;
      for (let j = 0; j < nc; j++) {
        const d = lat[j], y = groundY(s, d), k = (i * nc + j) * 3, ad = Math.abs(d);
        let yy = y;
        if (ad <= W) { const rr = Math.exp(-Math.pow((d - line) / 0.55, 2)) + Math.exp(-Math.pow((d + line * 0.6 + 2) / 0.5, 2)) * 0.7; yy = y - rr * 0.05 + (hash2(i * 0.91, j * 3.7) - 0.5) * 0.06; }
        pos[k] = p.x + lx * d; pos[k + 1] = yy; pos[k + 2] = p.z + lz * d;
        const n = 0.88 + 0.24 * hash2(i * 0.37, j * 1.7);
        let r = dirt[0], g = dirt[1], b = dirt[2], f = 1;
        if (ad <= W + 0.3) {
          const rut = Math.exp(-Math.pow((d - line) / 0.9, 2)) * 0.12 + Math.exp(-Math.pow((d + line * 0.6 + 2) / 0.7, 2)) * 0.08;
          f = n * (1 - rut) * (T.cat === 'sx' ? 0.9 : 1);
        } else {
          const bm = smooth((ad - W - 0.6) / 1.5), gg = smooth((ad - W - 3) / 5);
          f = n * (1 - 0.18 * bm);
          r = dirt[0] * (1 - gg) + gnd[0] * gg; g = dirt[1] * (1 - gg) + gnd[1] * gg; b = dirt[2] * (1 - gg) + gnd[2] * gg;
          if (T.cat === 'mx' || T.cat === 'pit') { const gv = 0.85 + 0.3 * hash2(i * 0.11 + 3, j * 0.9); f *= (1 - gg) + gg * gv; }
        }
        col[k] = r * f; col[k + 1] = g * f; col[k + 2] = b * f;
      }
    }
    const idx = [];
    for (let i = 0; i < nr - 1; i++) for (let j = 0; j < nc - 1; j++) {
      const A = i * nc + j, B = (i + 1) * nc + j, C = i * nc + j + 1, D = (i + 1) * nc + j + 1;
      idx.push(A, B, C, B, D, C);
    }
    for (let q = 0; q < idx.length; q += 3) {
      const a = idx[q] * 3, b = idx[q + 1] * 3, c = idx[q + 2] * 3;
      const ux = pos[b] - pos[a], uy = pos[b + 1] - pos[a + 1], uz = pos[b + 2] - pos[a + 2], vx = pos[c] - pos[a], vy = pos[c + 1] - pos[a + 1], vz = pos[c + 2] - pos[a + 2];
      const nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
      [a, b, c].forEach(o => { nor[o] += nx; nor[o + 1] += ny; nor[o + 2] += nz; });
    }
    const geo = new GF.Geo();
    for (let v = 0; v < nr * nc; v++) {
      const k = v * 3, l = Math.hypot(nor[k], nor[k + 1], nor[k + 2]) || 1;
      geo.v.push(pos[k], pos[k + 1], pos[k + 2], nor[k] / l, nor[k + 1] / l, nor[k + 2] / l, col[k], col[k + 1], col[k + 2]);
    }
    geo.n = nr * nc; geo.i = idx;
    return GF.upload(geo);
  }

  function buildScenery() {
    const solid = new GF.Geo(), crowd = new GF.Geo(), emis = new GF.Geo();
    const rnd = mulberry(T.n * 977 + 5), W = T.half, sEnd = (T.arr.length - 1) * DX, cat = T.cat, acc = T.theme.accent;
    const P = (s, d) => { const p = T.pos(s); return { x: p.x - Math.sin(p.th) * d, z: p.z - Math.cos(p.th) * d, th: p.th }; };
    const GY = (s, d) => groundY(s, d);
    const palette = ['#e63946', '#f4a261', '#2a9d8f', '#457b9d', '#ffd166', '#e9ecef', '#9b5de5', '#06d6a0'];

    // --- hay bales / padded barriers on the outside of corners
    const bale = cat === 'sx' ? null : '#c9a85a';
    for (let s = 20; s < T.finishX; s += 1.5) {
      const k = T.curv(s); if (Math.abs(k) < 0.009) continue;
      const d = (k > 0 ? -1 : 1) * (W + 0.75), p = P(s, d), y = GY(s, d);
      if (cat === 'sx') { addBox(solid, p.x, y + 0.45, p.z, 1.6, 0.9, 0.6, p.th, ((s / 1.5) | 0) % 2 ? acc : '#f1f1f1'); }
      else if (cat === 'pit') { addCyl(solid, p.x, y, p.z, 0.75, 0.3, '#151515', SHP.cyl8); addCyl(solid, p.x, y + 0.3, p.z, 0.75, 0.3, '#1d1d1d', SHP.cyl8); addCyl(solid, p.x, y + 0.6, p.z, 0.75, 0.3, '#151515', SHP.cyl8); }
      else { addBox(solid, p.x, y + 0.3, p.z, 1.3, 0.6, 0.6, p.th + (rnd() - 0.5) * 0.2, varyCol(bale, 0.85 + rnd() * 0.3)); if (Math.abs(k) > 0.016) addBox(solid, p.x, y + 0.9, p.z, 1.3, 0.6, 0.6, p.th, varyCol(bale, 0.8 + rnd() * 0.3)); }
    }

    // --- start / finish structures
    const fin = T.finishX;
    for (let sgn = -1; sgn <= 1; sgn += 2) {
      const d = sgn * (W + 1.4), p = P(fin, d), y = GY(fin, d);
      addBox(solid, p.x, y + 2.8, p.z, 0.35, 5.6, 0.35, p.th, '#e5e5e8');
    }
    for (let c = 0; c < 14; c++) for (let r = 0; r < 3; r++) {
      const d = -(W + 1.4) + (c + 0.5) * ((2 * W + 2.8) / 14), p = P(fin, d), y = GY(fin, 0);
      addBox(solid, p.x, y + 5.9 - r * 0.38 + 0.1, p.z, 0.2, 0.38, (2 * W + 2.8) / 14, p.th, (c + r) % 2 ? '#101010' : '#f5f5f5');
    }
    for (let c = 0; c < Math.floor(2 * W / 0.8); c++) for (let r = 0; r < 2; r++) {
      const d = -W + (c + 0.5) * 0.8, p = P(fin + r * 0.8, d), y = GY(fin, 0);
      addBox(solid, p.x, y + 0.03, p.z, 0.8, 0.04, 0.8, p.th, (c + r) % 2 ? '#101010' : '#f5f5f5');
    }
    for (let sgn = -1; sgn <= 1; sgn += 2) {                         // start gate posts
      const d = sgn * (W + 0.9), p = P(T.startX + 2.2, d), y = GY(T.startX + 2.2, 0);
      addBox(solid, p.x, y + 0.7, p.z, 0.2, 1.4, 0.2, p.th, '#d9d9dd');
    }
    // distance boards
    for (let m = 100; m < T.len; m += 100) {
      const s = T.startX + m, d = W + 1.6, p = P(s, d), y = GY(s, d);
      addBox(solid, p.x, y + 0.9, p.z, 0.1, 1.8, 0.1, p.th, '#dddddd');
      addBox(solid, p.x, y + 1.9, p.z, 0.08, 0.8, 1.2, p.th, '#f3f3f3');
      for (let q = 0; q < m / 100; q++) addBox(solid, p.x, y + 1.9, p.z + (q - (m / 100 - 1) / 2) * 0.0, 0.1, 0.55, 0.07, p.th, '#111', 0);
    }

    // --- category scenery
    if (cat === 'sx') {
      const n = Math.floor(sEnd / 14);
      for (let i = 0; i < n; i++) {
        const s = i * 14 + 7;
        for (let sgn = -1; sgn <= 1; sgn += 2) {
          const k = T.curv(s), inner = (sgn * k > 0);
          if (inner && 1 / Math.max(Math.abs(k), 1e-4) < W + 30) continue;
          const d = sgn * (W + 16), p = P(s, d), y0 = GY(s, d) - 1.2;
          addBox(crowd, p.x, y0 + 2.4, p.z, 14, 4.8, 7, p.th, '#8a8a99');
          const p2 = P(s, sgn * (W + 22)); addBox(crowd, p2.x, y0 + 4.6, p2.z, 14, 9.2, 6, p2.th, '#8a8a99');
          const pb = P(s, sgn * (W + 12.4));
          addBox(emis, pb.x, GY(s, sgn * (W + 12.4)) + 0.55, pb.z, 13.6, 1.0, 0.25, pb.th, palette[(i * 3 + (sgn > 0 ? 1 : 0)) % palette.length]);
          const pr = P(s, sgn * (W + 27)); addBox(solid, pr.x, y0 + 10.5, pr.z, 14, 0.5, 8, pr.th + 0, '#1b1d29');
        }
        if (i % 5 === 2) for (let sgn = -1; sgn <= 1; sgn += 2) {
          const d = sgn * (W + 11.5), p = P(s, d), y = GY(s, d);
          const k = T.curv(s); if (sgn * k > 0 && Math.abs(k) > 0.005) continue;
          addCyl(solid, p.x, y - 0.5, p.z, 0.5, 17, '#2a2d3a', SHP.cyl8);
          addBox(emis, p.x, y + 16.4, p.z, 0.6, 1.8, 5.2, p.th, '#fffbe8');
          addBox(emis, p.x, y + 14.8, p.z, 0.6, 1.2, 4.4, p.th, '#fff4cf');
        }
      }
    } else if (cat === 'mx' || cat === 'cmp' || cat === 'pit') {
      const dens = cat === 'pit' ? 0.7 : cat === 'cmp' ? 0.35 : 1.0;
      for (let s = 10; s < sEnd; s += 5) {
        for (let sgn = -1; sgn <= 1; sgn += 2) {
          if (rnd() > dens) continue;
          const dd = W + (cat === 'pit' ? 8 : 12) + rnd() * (cat === 'pit' ? 18 : 55);
          const k = T.curv(s); if (sgn * k > 0 && 1 / Math.max(Math.abs(k), 1e-4) < dd + 12) continue;
          const d = sgn * dd, p = P(s + rnd() * 4, d), y = GY(s, d), sz = 0.8 + rnd() * 0.8;
          if (cat === 'cmp') {
            if (rnd() < 0.5) { addCyl(solid, p.x, y, p.z, 0.3 * sz, 3.6 * sz, '#5c4a38'); addCyl(solid, p.x + 0.5, y + 2.2 * sz, p.z, 0.12 * sz, 1.8 * sz, '#5c4a38'); addCyl(solid, p.x - 0.4, y + 2.6 * sz, p.z + 0.3, 0.1 * sz, 1.4 * sz, '#5c4a38'); }
            else addSph(solid, p.x, y + 0.5 * sz, p.z, 2.2 * sz, 1.3 * sz, 2.0 * sz, varyCol('#6f7a45', 0.8 + rnd() * 0.4));
          } else {
            const gc = cat === 'pit' ? '#3f7f3b' : '#2b6b3f';
            addCyl(solid, p.x, y - 0.1, p.z, 0.45 * sz, 2.2 * sz, '#5a3f28');
            if (cat === 'mx' && rnd() < 0.8) { addCone(solid, p.x, y + 1.2 * sz, p.z, 3.2 * sz, 5.2 * sz, varyCol(gc, 0.75 + rnd() * 0.4), SHP.cone8); addCone(solid, p.x, y + 3.6 * sz, p.z, 2.4 * sz, 4.2 * sz, varyCol(gc, 0.85 + rnd() * 0.4), SHP.cone8); }
            else addSph(solid, p.x, y + 3.2 * sz, p.z, 3.6 * sz, 3.2 * sz, 3.6 * sz, varyCol('#4c8f3e', 0.75 + rnd() * 0.5));
          }
        }
      }
    }
    if (cat === 'pit') {                                              // wooden fence + houses
      for (let s = 3; s < sEnd; s += 2.5) for (let sgn = -1; sgn <= 1; sgn += 2) {
        const k = T.curv(s); const d = sgn * (W + 3.2), p = P(s, d), y = GY(s, d);
        if (sgn * k > 0 && Math.abs(k) > 0.006) continue;
        addBox(solid, p.x, y + 0.6, p.z, 0.14, 1.2, 0.14, p.th, '#8a6a46');
        addBox(solid, p.x, y + 0.45, p.z, 2.6, 0.1, 0.06, p.th, '#9b7a52'); addBox(solid, p.x, y + 0.9, p.z, 2.6, 0.1, 0.06, p.th, '#9b7a52');
      }
      for (let s = 40; s < sEnd; s += 70 + rnd() * 40) for (let sgn = -1; sgn <= 1; sgn += 2) {
        if (rnd() < 0.3) continue;
        const dd = W + 24 + rnd() * 14, k = T.curv(s); if (sgn * k > 0 && 1 / Math.max(Math.abs(k), 1e-4) < dd + 10) continue;
        const d = sgn * dd, p = P(s, d), y = GY(s, d), w = 8 + rnd() * 4;
        addBox(solid, p.x, y + 2, p.z, w, 4, 7, p.th, ['#d9c7a5', '#c6d1da', '#d7a58d', '#e6e0cf'][(rnd() * 4) | 0]);
        addCone(solid, p.x, y + 4, p.z, w * 1.25, 2.6, '#8a3b2f', SHP.cone4, PI / 4 + p.th);
        addBox(solid, p.x + Math.cos(p.th) * 0, y + 1.2, p.z, 1.2, 1.8, 7.1, p.th, '#4a3426');
      }
    }
    if (cat === 'cmp') {
      for (let s = 30; s < sEnd; s += 38 + rnd() * 40) for (let sgn = -1; sgn <= 1; sgn += 2) {
        if (rnd() < 0.35) continue;
        const dd = W + 14 + rnd() * 30, k = T.curv(s); if (sgn * k > 0 && 1 / Math.max(Math.abs(k), 1e-4) < dd + 10) continue;
        const d = sgn * dd, p = P(s, d), y = GY(s, d), cc = ['#3f6aa0', '#a0453a', '#4a7d52', '#c79a3a', '#7d7f85'][(rnd() * 5) | 0];
        addBox(solid, p.x, y + 1.3, p.z, 6.1, 2.6, 2.45, p.th + (rnd() - 0.5) * 0.4, cc);
        if (rnd() < 0.35) addBox(solid, p.x, y + 3.9, p.z, 6.1, 2.6, 2.45, p.th, varyCol(cc, 0.85));
      }
      for (let s = 20; s < sEnd; s += 14 + rnd() * 20) for (let sgn = -1; sgn <= 1; sgn += 2) {
        if (rnd() < 0.5) continue;
        const dd = W + 6 + rnd() * 20, k = T.curv(s); if (sgn * k > 0 && 1 / Math.max(Math.abs(k), 1e-4) < dd + 8) continue;
        const d = sgn * dd, p = P(s, d), y = GY(s, d), sz = 0.7 + rnd() * 1.6;
        addSph(solid, p.x, y + 0.3 * sz, p.z, 2.4 * sz, 1.2 * sz, 2.0 * sz, varyCol('#8a7a68', 0.7 + rnd() * 0.5));
      }
    }
    if (cat === 'mx') {                                               // banners and tents
      for (let s = 50; s < sEnd; s += 60 + rnd() * 30) for (let sgn = -1; sgn <= 1; sgn += 2) {
        const dd = W + 3.5, k = T.curv(s); if (sgn * k > 0 && Math.abs(k) > 0.005) continue;
        const d = sgn * dd, p = P(s, d), y = GY(s, d), col = palette[(rnd() * palette.length) | 0];
        addCyl(solid, p.x, y, p.z, 0.1, 5, '#ccc'); addBox(solid, p.x, y + 4.2, p.z + 0.0, 0.05, 1.3, 2.2, p.th, col);
      }
      for (let s = 80; s < sEnd; s += 140 + rnd() * 90) {
        const sgn = rnd() < 0.5 ? -1 : 1, dd = W + 16 + rnd() * 6, k = T.curv(s); if (sgn * k > 0 && 1 / Math.max(Math.abs(k), 1e-4) < dd + 10) continue;
        const d = sgn * dd, p = P(s, d), y = GY(s, d);
        addBox(solid, p.x, y + 1.4, p.z, 6, 2.8, 6, p.th, '#f0f0f0'); addCone(solid, p.x, y + 2.8, p.z, 9, 2.2, palette[(rnd() * 4) | 0], SHP.cone4, PI / 4 + p.th);
      }
    }
    // far mountains / hills
    if (cat !== 'sx') {
      const hc = cat === 'pit' ? '#6f9a72' : cat === 'cmp' ? '#b8855a' : '#5f7d8a';
      for (let s = -100; s < sEnd + 100; s += 160 + rnd() * 80) for (let sgn = -1; sgn <= 1; sgn += 2) {
        const d = sgn * (330 + rnd() * 250), p = P(s, d), r = 110 + rnd() * 160, h = (cat === 'pit' ? 30 : 60) + rnd() * 110;
        addCone(solid, p.x, T.base - 4, p.z, r * 2, h, varyCol(hc, 0.8 + rnd() * 0.4), SHP.cone8, rnd() * 3);
      }
    }
    return { solid: GF.upload(solid), crowd: crowd.n ? GF.upload(crowd) : null, emis: emis.n ? GF.upload(emis) : null };
  }

  function setEnv() {
    const e = GF.env, th = T.theme, cat = T.cat, rnd = mulberry(T.n * 13 + 1);
    const L = GF.lin, sc = (c, f) => c.map(v => v * f);
    e.top = L(th.sky[0]); e.hor = L(th.sky[1]);
    if (cat === 'sx') {
      e.sunDir = norm([0.25, 0.9, 0.35]); e.sunCol = [1.7, 1.55, 1.3]; e.skyCol = sc(L(th.sky[1]), 3.2); e.gndCol = [0.05, 0.05, 0.06]; e.fogCol = sc(L(th.sky[1]), 0.8); e.fogDen = 0.0042;
      e.gnd = sc(L(th.sky[0]), 0.6); e.night = 1; e.cloud = 0;
    } else {
      const dusk = th.variant === 3, el = dusk ? 0.22 : 0.55 + rnd() * 0.3, az = rnd() * 6.28;
      e.sunDir = norm([Math.cos(az) * Math.cos(el), Math.sin(el), Math.sin(az) * Math.cos(el)]);
      e.sunCol = dusk ? [2.4, 1.25, 0.55] : [2.5, 2.3, 2.0];
      e.skyCol = sc(L(th.sky[0]), dusk ? 1.2 : 1.5); e.gndCol = sc(L(GROUND[cat]), 0.55);
      e.fogCol = sc(e.hor, 1.0); e.fogDen = cat === 'cmp' ? 0.0042 : 0.0035;
      e.gnd = sc(L(GROUND[cat]), 0.8); e.night = 0; e.cloud = 0.8;
    }
  }
  function norm(v) { const l = Math.hypot(v[0], v[1], v[2]); return [v[0] / l, v[1] / l, v[2] / l]; }

  R3.setTrack = function (G) {
    R3.clear();
    T = G.T;
    T.base = T.minH - 2.5;
    const hillN = (s, d) => Math.sin(s * 0.017 + d * 0.031) * 0.5 + Math.sin(s * 0.041 - d * 0.023 + 1.3) * 0.3 + Math.sin(s * 0.0071 + d * 0.011) * 0.6;
    W3 = (s, d, y) => { const p = T.pos(s); return [p.x - Math.sin(p.th) * d, y, p.z - Math.cos(p.th) * d]; };
    groundY = (s, d) => {
      const W = T.half, ad = Math.abs(d), hc = T.h(s);
      if (ad <= W) return hc;
      const hs = T.hsF(s), b = smooth((ad - W) / 3);
      let y = hc * (1 - b) + hs * b;
      const k = T.curv(s), outer = (d * k < 0), bermH = T.bermH + (outer ? Math.min(1.4, Math.abs(k) * 26) : 0), bp = ad - W;
      const bump = bp < 1.2 ? smooth(bp / 1.2) : (bp < 3.2 ? 1 - 0.3 * smooth((bp - 1.2) / 2) : 0.7 * (1 - smooth((bp - 3.2) / 6)));
      y += bermH * bump;
      const t = smooth((ad - W - 3) / (T.ext - 3)), far = T.base + LAND[T.cat] * hillN(s, d) * smooth((ad - W - 6) / 8) * (1 - t);
      return y * (1 - t) + far * t;
    };
    setEnv();
    world = { terrain: buildTerrain(), sc: buildScenery() };
    const mid = T.pos(T.finishX / 2);
    world.cx = mid.x; world.cz = mid.z;
    cam.init = true;
  };
  R3.clear = function () {
    if (world) { GF.free(world.terrain); GF.free(world.sc.solid); GF.free(world.sc.crowd); GF.free(world.sc.emis); world = null; }
  };
  R3.resize = function (w, h, dpr) { GF.resize(w, h, dpr); };

  /* ---------- bike + rider model ---------- */
  function classShapes(C) {
    const key = C.label;
    if (shapeCache[key]) return shapeCache[key];
    const tire = GF.upload((function () { const g = new GF.Geo(); g.add(SH.torus(C.r - 0.055, 0.075, 30, 10, 14), M.ident(), null); return g; })());
    return (shapeCache[key] = { tire });
  }
  const col = {};
  const cc = h => col[h] || (col[h] = GF.rgb(h));

  function drawBike(b, isPlayer, mode, G, shadowPass) {
    const C = b.C, sc = C.sc, wb = C.wb, rx = C.rx, fx = C.fx, hy = C.hy, shp = classShapes(C);
    const p = T.pos(b.x), th = p.th + b.yawOff, wp = W3(b.x, b.d, b.y);
    const root = M.chain(M.T(wp[0], wp[1], wp[2]), M.Ry(th), M.Rz(b.a), M.Rx(-b.roll));
    const rp = Math.min(b.rPen, 0.26), fpn = Math.min(b.fPen, 0.26);
    const U = (a, v, z) => [rx + a * wb, hy + v * sc, z || 0];
    const pivot = U(0.28, 0.12), head = U(0.90, 0.78), seatR = U(0.18, 0.62), seatF = U(0.60, 0.68), tank = U(0.72, 0.74), eng = U(0.5, 0.3);
    const rear = [rx, hy + rp, 0], front = [fx, hy + fpn, 0];
    const steerM = M.chain(M.T(head[0], head[1], head[2]), M.Ry(b.steerVis), M.T(-head[0], -head[1], -head[2]));
    const plastic = cc(b.color), dark = cc('#1b1d23'), metal = cc('#b9bec7'), frameC = cc('#8e95a1'), tireC = cc('#222'), engC = cc('#2c2f37'), gold = cc('#d9b455'), white = cc('#f2f2f4'), blk = cc('#0f1013');
    const SP = 0.04;
    const D = (shape, local, tint, o) => GF.draw(shape, M.mul(root, local), tint, o || { spec: 0.35 });
    const Dsteer = (shape, local, tint, o) => GF.draw(shape, M.chain(root, steerM, local), tint, o || { spec: 0.35 });
    const btw = (shape, a, bb, sx, sz, tint, steer) => (steer ? Dsteer : D)(shape, M.between(a, bb, sx, sz), tint);
    const add = (a, o) => [a[0] + o[0], a[1] + o[1], a[2] + o[2]];

    // wheels
    const wheel = (c, steerIt) => {
      const f = steerIt ? Dsteer : D, r = C.r;
      f(shp.tire, M.chain(M.T(c[0], c[1], c[2]), M.Rz(-b.wr)), tireC, { spec: 0.05 });
      f(GS.cyl, M.chain(M.T(c[0], c[1], c[2]), M.Rx(PI / 2), M.S((r - 0.1) * 2, 0.1, (r - 0.1) * 2)), metal);
      f(GS.cyl, M.chain(M.T(c[0], c[1], c[2]), M.Rx(PI / 2), M.S(0.12, 0.2, 0.12)), cc('#6b707a'));
      for (let k = 0; k < 3; k++) f(GS.box, M.chain(M.T(c[0], c[1], c[2]), M.Rz(-b.wr + k * PI / 3), M.S((r - 0.1) * 2, 0.012, 0.014)), metal);
      f(GS.cyl, M.chain(M.T(c[0], c[1], c[2] + 0.055), M.Rx(PI / 2), M.S(0.2, 0.008, 0.2)), cc('#9a9ea8'));
    };
    wheel(rear, false); wheel(front, true);
    // swingarm, shock, frame
    for (let s = -1; s <= 1; s += 2) {
      btw(GS.cyl, add(pivot, [0, 0, s * 0.1]), add(rear, [0, 0, s * 0.1]), 0.05, 0.05, frameC);
      btw(GS.cyl, add(head, [0, 0, s * 0.07]), add(pivot, [0, 0, s * 0.09]), 0.045, 0.045, frameC);
      btw(GS.cyl, add(head, [0, 0, s * 0.06]), add(seatR, [0, 0, s * 0.08]), 0.04, 0.04, frameC);
      btw(GS.cyl, add(pivot, [0, 0, s * 0.09]), add(seatR, [0, 0, s * 0.08]), 0.04, 0.04, frameC);
    }
    btw(GS.cyl, U(0.38, 0.58), U(0.24, 0.16), 0.07, 0.07, cc('#e8b923'));
    // engine
    D(GS.box, M.chain(M.T(eng[0], eng[1], 0), M.S(0.36 * wb / 1.46, 0.3 * sc, 0.2)), engC);
    D(GS.box, M.chain(M.T(eng[0] + 0.04, eng[1] + 0.2 * sc, 0), M.Rz(0.45), M.S(0.2, 0.2 * sc, 0.17)), cc('#3b3f49'));
    D(GS.box, M.chain(M.T(eng[0], eng[1] - 0.17 * sc, 0), M.S(0.4 * wb / 1.46, 0.04, 0.2)), cc('#8a8f99'));
    // exhaust
    for (let s = 1; s <= 1; s++) {
      const z = 0.17, e1 = add(eng, [0.14, 0.12, z]), e2 = U(0.22, 0.27, z), e3 = U(0.14, 0.52, z), e4 = U(-0.07, 0.66, z);
      btw(GS.cyl, e1, e2, 0.045, 0.045, metal); btw(GS.cyl, e2, e3, 0.05, 0.05, metal); btw(GS.cyl, e3, e4, 0.11, 0.11, cc('#cfd3da'));
    }
    // chain, pegs
    btw(GS.box, add(rear, [0, 0, 0.09]), add(eng, [-0.08, -0.05, 0.1]), 0.012, 0.02, blk);
    for (let s = -1; s <= 1; s += 2) D(GS.box, M.chain(M.T(U(0.46, 0.22)[0], U(0.46, 0.22)[1], s * 0.2), M.S(0.1, 0.03, 0.06)), metal);
    // plastics
    D(GS.sph, M.chain(M.T(tank[0], tank[1], 0), M.Rz(-0.05), M.S(0.42 * wb / 1.46, 0.2 * sc, 0.3)), plastic, { spec: 0.5 });
    btw(GS.box, seatR, seatF, 0.1, 0.22, dark);
    btw(GS.box, add(seatR, [0.02, 0.04, 0]), U(-0.04, 0.54), 0.05, 0.18, plastic);
    for (let s = -1; s <= 1; s += 2) {
      btw(GS.box, U(0.5, 0.6, s * 0.14), U(0.84, 0.42, s * 0.14), 0.07, 0.15, plastic);
      D(GS.box, M.chain(M.T(U(0.26, 0.5)[0], U(0.26, 0.5)[1], s * 0.145), M.Rz(0.1), M.S(0.26, 0.2, 0.012)), white);
      D(GS.sph, M.chain(M.T(U(0.26, 0.5)[0], U(0.26, 0.5)[1], s * 0.152), M.S(0.12, 0.12, 0.012)), blk);
    }
    // front end
    for (let s = -1; s <= 1; s += 2) {
      btw(GS.cyl, add(head, [0, 0, s * 0.07]), add(front, [0, 0, s * 0.07]), 0.048, 0.048, gold, true);
      const mid = [head[0] * 0.35 + front[0] * 0.65, head[1] * 0.35 + front[1] * 0.65, s * 0.07];
      btw(GS.cyl, mid, add(front, [0, 0, s * 0.07]), 0.04, 0.04, metal, true);
    }
    Dsteer(GS.box, M.chain(M.T(front[0] + 0.04, front[1] + C.r + 0.07, 0), M.Rz(-0.08), M.S(0.58, 0.035, 0.15)), plastic);
    Dsteer(GS.box, M.chain(M.T(head[0] + 0.12, head[1] + 0.02, 0), M.Rz(-0.35), M.S(0.03, 0.22, 0.2)), white);
    Dsteer(GS.box, M.chain(M.T(head[0] + 0.135, head[1] + 0.02, 0), M.Rz(-0.35), M.S(0.012, 0.14, 0.13)), blk);
    const barC = [head[0] - 0.03, head[1] + 0.12, 0];
    Dsteer(GS.cyl, M.chain(M.T(barC[0], barC[1], 0), M.Rx(PI / 2), M.S(0.024, 0.78, 0.024)), cc('#3a3d45'));
    for (let s = -1; s <= 1; s += 2) Dsteer(GS.cyl, M.chain(M.T(barC[0], barC[1], s * 0.34), M.Rx(PI / 2), M.S(0.034, 0.13, 0.034)), blk);

    // rider
    const hideHelm = isPlayer && mode === 2;
    const rp2 = (function () { const hip = [rx + 0.30 * wb, hy + 0.68 * sc], t = 0.55 - 0.5 * b.pose, s = Math.sin(t), c = Math.cos(t); const sh = [hip[0] + s * 0.56, hip[1] + c * 0.56]; return { hip, sh, head: [sh[0] + s * 0.24, sh[1] + c * 0.24] }; })();
    let riderBase = root, off = [0, 0, 0];
    if (b.dead && b.rag) {
      const r = b.rag, w = W3(r.s, r.d, r.y), hp = rp2.hip;
      riderBase = M.chain(M.T(w[0], w[1], w[2]), M.Rx(r.ax), M.Ry(r.ay), M.Rz(r.az), M.T(-hp[0], -hp[1], 0));
    }
    const RD = (shape, local, tint, o) => GF.draw(shape, M.mul(riderBase, local), tint, o || { spec: 0.15 });
    const RB = (shape, a, bb, sx, sz, tint) => RD(shape, M.between(a, bb, sx, sz), tint);
    const pants = cc('#1a1e2a'), glove = cc('#202228'), boot = cc('#e9e9ee');
    const hipC = [rp2.hip[0], rp2.hip[1], 0], shC = [rp2.sh[0], rp2.sh[1], 0], hd = [rp2.head[0], rp2.head[1], 0];
    const ryaw = (pt) => { const x = pt[0] - head[0], z = pt[2], c = Math.cos(b.steerVis), s = Math.sin(b.steerVis); return [head[0] + x * c + z * s, pt[1], -x * s + z * c]; };
    for (let s = -1; s <= 1; s += 2) {
      const hipP = [hipC[0], hipC[1], s * 0.11], peg = U(0.46, 0.25, s * 0.2), knee = [(hipP[0] + peg[0]) / 2 + 0.17, (hipP[1] + peg[1]) / 2 + 0.03, s * 0.2];
      const shP = [shC[0], shC[1], s * 0.19], hand = ryaw([barC[0], barC[1], s * 0.34]), elb = [(shP[0] + hand[0]) / 2 - 0.02, (shP[1] + hand[1]) / 2 - 0.13, s * 0.3];
      RB(GS.cyl, hipP, knee, 0.17, 0.17, pants); RB(GS.cyl, knee, add(peg, [0, 0.07, 0]), 0.14, 0.14, pants);
      RD(GS.box, M.chain(M.T(peg[0] + 0.03, peg[1] + 0.04, peg[2]), M.Rz(0.1), M.S(0.3, 0.12, 0.1)), boot);
      RB(GS.cyl, shP, elb, 0.1, 0.1, cc(b.color)); RB(GS.cyl, elb, hand, 0.085, 0.085, glove);
      RD(GS.sph, M.chain(M.T(elb[0], elb[1], elb[2]), M.S(0.115, 0.115, 0.115)), cc(b.color)); RD(GS.sph, M.chain(M.T(shP[0], shP[1], shP[2]), M.S(0.15, 0.15, 0.15)), cc(b.color));
      RD(GS.sph, M.chain(M.T(knee[0], knee[1], knee[2]), M.S(0.185, 0.185, 0.185)), cc('#262b3a'));
      RD(GS.sph, M.chain(M.T(hand[0], hand[1], hand[2]), M.S(0.11, 0.11, 0.11)), glove);
    }
    RD(GS.sph, M.chain(M.T(hipC[0], hipC[1], 0), M.S(0.27, 0.24, 0.3)), pants);
    RB(GS.box, hipC, shC, 0.2, 0.34, cc(b.color));
    RB(GS.box, [hipC[0] * 0.3 + shC[0] * 0.7, hipC[1] * 0.3 + shC[1] * 0.7, 0], [shC[0], shC[1] + 0.03, 0], 0.23, 0.38, cc(shade(b.color)));
    if (!hideHelm) {
      RD(GS.sph, M.chain(M.T(hd[0], hd[1], 0), M.S(0.31, 0.29, 0.29)), white, { spec: 0.6 });
      RD(GS.box, M.chain(M.T(hd[0] + 0.15, hd[1] + 0.09, 0), M.Rz(-0.25), M.S(0.16, 0.02, 0.22)), cc(b.color));
      RD(GS.box, M.chain(M.T(hd[0] + 0.14, hd[1] + 0.005, 0), M.S(0.07, 0.1, 0.23)), cc('#20242c'));
      RD(GS.box, M.chain(M.T(hd[0] + 0.15, hd[1] - 0.1, 0), M.S(0.1, 0.09, 0.17)), white);
      RD(GS.box, M.chain(M.T(hd[0], hd[1] + 0.13, 0), M.S(0.04, 0.03, 0.2)), cc(b.color));
    }

    // blob shadow
    if (!shadowPass) {
      const gh = T.h(b.x), height = Math.max(0, b.y - gh - 0.7), sl = Math.atan2(T.h(b.x + 0.8) - T.h(b.x - 0.8), 1.6), sp = W3(b.x, b.d, gh + 0.05);
      GF.blend(true);
      GF.draw(GS.sph, M.chain(M.T(sp[0], sp[1], sp[2]), M.Ry(p.th + b.yawOff * 0.5), M.Rz(sl), M.S(2.3, 0.02, 0.95)), [0, 0, 0], { mode: 1, alpha: 0.22 * clamp(1 - height / 7, 0.1, 1) });
      GF.blend(false);
    }
  }
  function shade(hex) { const c = GF.rgb(hex); return 'rgb(' + (c[0] * 190 | 0) + ',' + (c[1] * 190 | 0) + ',' + (c[2] * 190 | 0) + ')'; }

  /* ---------- tyre tracks ---------- */
  const trails = new WeakMap();
  function updateTrails(G) {
    for (const b of G.riders) {
      let tr = trails.get(b); if (!tr) { tr = []; trails.set(b, tr); }
      if (b.dead || !(b.grounded & 1) || b.vx < 2) { if (tr.length && !tr.brk) { tr.brk = true; } continue; }
      const L = tr[tr.length - 1];
      if (!L || tr.brk || Math.abs(b.x - L.s) > 4 || Math.abs(b.d - L.d) > 3) { tr.push({ s: b.x, d: b.d, a: 0, g: 1 }); tr.brk = false; continue; }
      if (Math.abs(b.x - L.s) >= 0.4 || Math.abs(b.d - L.d) >= 0.3) { tr.push({ s: b.x, d: b.d, a: clamp(b.thr, 0, 1), g: 0 }); if (tr.length > 520) tr.shift(); }
    }
  }
  function drawTrails(G) {
    const v = [], idx = [], P0 = G.player.x; let n = 0;
    const push = (x, y, z, sh) => { v.push(x, y, z, 0, 1, 0, sh, sh, sh); return n++; };
    for (const b of G.riders) {
      const tr = trails.get(b); if (!tr) continue;
      for (let i = 1; i < tr.length; i++) {
        const a = tr[i - 1], c = tr[i]; if (c.g) continue;
        if (Math.abs(c.s - P0) > 90) continue;
        const w = 0.07 + c.a * 0.03;
        for (let k = 0; k < 2; k++) {
          const off = k ? 0.0 : 0.0;
          const a0 = W3(a.s, a.d - w, T.h(a.s) + 0.035), a1 = W3(a.s, a.d + w, T.h(a.s) + 0.035), c0 = W3(c.s, c.d - w, T.h(c.s) + 0.035), c1 = W3(c.s, c.d + w, T.h(c.s) + 0.035);
          const sh = 0.55 - c.a * 0.15, q0 = push(a0[0], a0[1], a0[2], sh), q1 = push(a1[0], a1[1], a1[2], sh), q2 = push(c0[0], c0[1], c0[2], sh), q3 = push(c1[0], c1[1], c1[2], sh);
          idx.push(q0, q1, q2, q1, q3, q2);
          break;
        }
      }
    }
    if (!idx.length) return;
    GF.blend(true);
    GF.drawDynamic(new Float32Array(v), new Uint32Array(idx), GF.rgb(T.theme.dirt).map(x => x * 0.7), { alpha: 0.5 });
    GF.blend(false);
  }

  /* ---------- camera ---------- */
  function updateCam(G, dt, mode) {
    const P = G.player, pos = T.pos(P.x), spd = Math.hypot(P.vx, P.vy);
    const th = pos.th + P.yawOff * 0.5;
    let diff = th - cam.th; while (diff > PI) diff -= 2 * PI; while (diff < -PI) diff += 2 * PI;
    if (cam.init) { cam.th = th; cam.ty = P.y; }
    cam.th += diff * (1 - Math.exp(-dt * (mode === 2 ? 16 : 4.5)));
    cam.ty += (P.y - cam.ty) * (1 - Math.exp(-dt * 5));
    const bw = W3(P.x, P.d, P.y), fwd = [Math.cos(cam.th), 0, -Math.sin(cam.th)];
    let eye, tgt, fov;
    if (mode === 2) {
      const C = P.C, sc = C.sc, t = 0.55 - 0.5 * P.pose, hip = [C.rx + 0.30 * C.wb, C.hy + 0.68 * sc];
      const hx = hip[0] + Math.sin(t) * 0.78, hy2 = hip[1] + Math.cos(t) * 0.78;
      const co = Math.cos(P.a), si = Math.sin(P.a), xs = P.x + hx * co - hy2 * si, ys = P.y + hx * si + hy2 * co;
      const w = W3(xs, P.d, ys + 0.03);
      eye = [w[0] + fwd[0] * 0.2, w[1], w[2] + fwd[2] * 0.2];
      const pitch = clamp(P.a * 0.4, -0.5, 0.5);
      tgt = [eye[0] + fwd[0] * 10 * Math.cos(pitch), eye[1] + 10 * Math.sin(pitch) - 1.3, eye[2] + fwd[2] * 10 * Math.cos(pitch)];
      fov = 78 + clamp(spd / 32, 0, 1) * 10; cam.px = eye[0]; cam.py = eye[1]; cam.pz = eye[2];
    } else {
      const dist = mode === 1 ? 8.8 : 5.1, hgt = mode === 1 ? 3.4 : 1.85;
      const des = [bw[0] - fwd[0] * dist, cam.ty + hgt, bw[2] - fwd[2] * dist];
      if (cam.init) { cam.px = des[0]; cam.py = des[1]; cam.pz = des[2]; }
      const k = 1 - Math.exp(-dt * 11);
      cam.px += (des[0] - cam.px) * k; cam.py += (des[1] - cam.py) * k; cam.pz += (des[2] - cam.pz) * k;
      const floor = T.h(P.x - dist) + 0.9;
      eye = [cam.px, Math.max(cam.py, floor), cam.pz];
      tgt = [bw[0] + fwd[0] * 5, cam.ty + 0.85, bw[2] + fwd[2] * 5];
      fov = (mode === 1 ? 58 : 62) + clamp(spd / 32, 0, 1) * 12;
    }
    cam.init = false;
    if (G.shake > 0) { G.shake = Math.max(0, G.shake - dt); const a = G.shake * 0.35; eye[0] += (Math.random() - 0.5) * a; eye[1] += (Math.random() - 0.5) * a; eye[2] += (Math.random() - 0.5) * a; }
    else if (spd > 18 && mode !== 2) { const a = 0.008 * (spd / 30); eye[1] += (Math.random() - 0.5) * a; }
    cam.fov += (fov - cam.fov) * (1 - Math.exp(-dt * 4));
    return { eye, tgt, fov: cam.fov };
  }

  /* ---------- frame ---------- */
  R3.render = function (G, dt, mode, time, paused) {
    if (!world) return;
    GF.setTime(time);
    const cm = updateCam(G, paused ? 0 : dt, mode), sz = GF.size(), asp = sz[0] / sz[1];
    const proj = M.persp(cm.fov * PI / 180, asp, 0.15, 1500), view = M.lookAt(cm.eye, cm.tgt, [0, 1, 0]), vp = M.mul(proj, view);
    let fx = cm.tgt[0] - cm.eye[0], fy = cm.tgt[1] - cm.eye[1], fz = cm.tgt[2] - cm.eye[2]; const fl = Math.hypot(fx, fy, fz); fx /= fl; fy /= fl; fz /= fl;
    let rxv = fy * 0 - fz * 1, ryv = fz * 0 - fx * 0, rzv = fx * 1 - fy * 0; // cross(fwd, up(0,1,0))
    rxv = -fz; ryv = 0; rzv = fx; const rl = Math.hypot(rxv, ryv, rzv) || 1; rxv /= rl; rzv /= rl;
    const ux = ryv * fz - rzv * fy, uy = rzv * fx - rxv * fz, uz = rxv * fy - ryv * fx;
    // ---- shadow map pass (sun orthographic, follows the player, snapped to texels)
    {
      const P0 = G.player, bw0 = W3(P0.x, P0.d, P0.y), sd = GF.env.sunDir, E = 46, texel = 2 * E / 2048;
      const fl = [-sd[0], -sd[1], -sd[2]];
      let lr = [fl[1] * 0 - fl[2] * 1, 0, fl[0] * 1 - fl[1] * 0]; lr = [-fl[2], 0, fl[0]]; const ll = Math.hypot(lr[0], lr[1], lr[2]) || 1; lr = [lr[0] / ll, 0, lr[2] / ll];
      const lu = [lr[1] * fl[2] - lr[2] * fl[1], lr[2] * fl[0] - lr[0] * fl[2], lr[0] * fl[1] - lr[1] * fl[0]];
      const cr = bw0[0] * lr[0] + bw0[1] * lr[1] + bw0[2] * lr[2], cu = bw0[0] * lu[0] + bw0[1] * lu[1] + bw0[2] * lu[2];
      const dr = Math.round(cr / texel) * texel - cr, du = Math.round(cu / texel) * texel - cu;
      const ctr = [bw0[0] + lr[0] * dr + lu[0] * du, bw0[1] + lr[1] * dr + lu[1] * du, bw0[2] + lr[2] * dr + lu[2] * du];
      const lview = M.lookAt([ctr[0] + sd[0] * 130, ctr[1] + sd[1] * 130, ctr[2] + sd[2] * 130], ctr, [0, 1, 0]);
      const lvp = M.mul(M.ortho(-E, E, -E, E, 5, 280), lview);
      if (GF.shadowBegin(lvp)) {
        GF.draw(world.terrain, null);
        GF.draw(world.sc.solid, null);
        for (const b of G.riders) if (Math.abs(b.x - P0.x) < 70) drawBike(b, b.player, mode, G, true);
        GF.shadowEnd();
      }
    }
    GF.begin(vp, cm.eye);
    GF.drawSky({ fwd: [fx, fy, fz], right: [rxv, ryv, rzv], up: [ux, uy, uz], tanH: Math.tan(cm.fov * PI / 360), asp });
    const T0 = T, cat = T0.cat;
    // ground plane + terrain + static scenery
    GF.draw(GS.box, M.chain(M.T(world.cx, T0.base - 0.55, world.cz), M.S(7000, 1, 7000)), GF.rgb(GROUND[cat]), { grain: 0.6, spec: 0 });
    GF.draw(world.terrain, null, [1, 1, 1], { grain: 1, spec: 0.06 });
    GF.draw(world.sc.solid, null, [1, 1, 1], { spec: 0.08 });
    if (world.sc.crowd) GF.draw(world.sc.crowd, null, [1, 1, 1], { mode: 2 });
    if (world.sc.emis) GF.draw(world.sc.emis, null, [1, 1, 1], { mode: 1 });
    // start gate plank + checkpoint flags
    {
      const gs = T0.startX + 2.2, p = T0.pos(gs), base = W3(gs, 0, T0.h(gs)), drop = G.state === 'racing' ? clamp(G.t / 0.35, 0, 1) : 0, W = T0.half;
      const seg = 8, sw = 2 * W / seg;
      for (let i = 0; i < seg; i++) {
        const d = -W + (i + 0.5) * sw, bp = W3(gs, d, T0.h(gs));
        GF.draw(GS.box, M.chain(M.T(bp[0], bp[1], bp[2]), M.Ry(p.th), M.Rz(-drop * 1.5), M.T(0, 0.5, 0), M.S(0.1, 1.0, sw)), i % 2 ? GF.rgb(T0.theme.accent) : cc('#f4f4f4'), { spec: 0.3 });
      }
      for (let i = 1; i < T0.cps.length; i++) {
        const s = T0.cps[i], pp = T0.pos(s), d = (W + 1.5), bp = W3(s, d, groundY(s, d)), passed = G.player.cp >= i;
        GF.draw(GS.box, M.chain(M.T(bp[0], bp[1] + 0.95, bp[2]), M.S(0.06, 1.9, 0.06)), cc('#dddddd'));
        GF.draw(GS.box, M.chain(M.T(bp[0], bp[1] + 1.65, bp[2]), M.Ry(pp.th), M.T(0, 0, 0.0), M.S(0.03, 0.4, 0.7)), passed ? cc('#22c55e') : cc('#f59e0b'), { mode: 1 });
      }
    }
    if (!paused) updateTrails(G);
    drawTrails(G);
    // bikes
    for (let i = G.riders.length - 1; i >= 0; i--) { const b = G.riders[i]; drawBike(b, b.player, mode, G); }
    // dust
    let n = 0; const dirt = GF.rgb(T0.theme.dirt), cl = cat === 'sx' ? 0.9 : 1.25;
    for (const q of G.parts) {
      if (n >= 400) break;
      const w = W3(q.s, q.d, q.y), k = n * 5, lf = q.life / q.max;
      ptData[k] = w[0]; ptData[k + 1] = w[1]; ptData[k + 2] = w[2]; ptData[k + 3] = q.size * 1.5; ptData[k + 4] = lf * lf * 0.5; n++;
    }
    GF.drawPoints(ptData, n, vp, sz[1] / (2 * Math.tan(cm.fov * PI / 360)), [clamp(dirt[0] * cl + 0.15, 0, 1), clamp(dirt[1] * cl + 0.12, 0, 1), clamp(dirt[2] * cl + 0.1, 0, 1)]);
    GF.endFrame(clamp((Math.hypot(G.player.vx, G.player.vy) - 14) / 22, 0, 1) * (mode === 2 ? 1.3 : 1));
  };

  window.R3 = R3;
})();
